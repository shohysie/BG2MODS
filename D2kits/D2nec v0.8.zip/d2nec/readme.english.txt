////////////////////////////////////////////////////
/////Diablo2 Kit Pack - The Necromancer Ver 0.8/////
////////////////////////////////////////////////////

----------ATTENTIONS----------

    It is a Cleric kit for BG2, BGT and EE series.
    Only one Necromancer(D2) is suggested in a whole game,  as multiple Necromancers' high-level skills and summonings will be in conflict.

    While on selection, skeletons, golems and revived creatures switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.
    Manually operating a Skeleton Mage to cast spell on an enemy will give him a mark, and all Skeleton Mages will focus on the enemy within four rounds.
    Golems and Bone Walls do not occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned. If one golem is imprisoned or petrified, a reverse magic is required to free it, or else another golem can't be summoned.

    Two extra components, the first one extends level limits of Corpse Explosion, Poison Explosion and Revive to LV.32 for players of Legacy of Bhaal mode; the second one makes all revived creatures able to follow the summoner across different areas, but may cause lags and bigger non-EE games save files, which is not recommended when some amount of other MOD has been installed.

----------KNOWN BUGS----------

    On entering some special areas, e.g. the third level of Watcher's Keep, summoned creatures that can follow the summoner across different areas may be lost behind. Try entering again to bring them along.

    Some skills and spells may be conflict with MOD items which have immunity from 'Removal: Remove Secondary Type'. Such problem does not exist in EE games.

----------DETAILED DESCRIPTION----------

Necromancer
From the steamy recesses of the southern swamps comes a figure cloaked in mystery. The Necromancer, as his name implies, is an unseemly form of sorcerer whose spells deal with the raising of the dead and the summoning and control of various creatures for his purposes. Though his goals are often aligned with those of the forces of Light, some do not think that these ends can justify his foul means. Long hours of study in dank mausolea have made his skin pale and corpselike, his figure, skeletal. Most people shun him for his peculiar looks and ways, but none doubt the power of the Necromancer, for it is the stuff of nightmares. 

Advantages:
- New divine spells and high-level skills: Summoning Spells, Poison and Bone Spells, Curses.
- Get bonus of +1 to intelligence and wisdom on character creation.

Disadvantages:
- May not learn divine spells and high-level skills of original clerics.
- May not be good alignments.
- May not turn endead.
- Get penalty of -2 to vitality and charisma on character creation.
- Unable to dual class.


Summoning Spells

Raise Skeleton (Necromancy)
Level: 1
Range: Visual sight of caster
Duration: 8 hours
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a skeleton with a melee weapon and a shield. The skeleton can follow the summoner, remain in an area and attack any enemy. It remain animated until it's destroyed in combat, 8 hours pass, or turned.
The skeletons gain a fighter's class and half the class level (up to 10) of their summoner. When a skeleton's class level increases, its abilities such as HP, THAC0 and save ability, also increase.
The skeletons equip normal weapons at the beginning, their equipments gain +1 enchantment with every 5 levels of the summoner, and become a maximum +4 enchanted when the summoner reaches level 20.
While on selection, skeletons switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Clay Golem (Necromancy)
Level: 2
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a clay golem. The golem can follow the summoner across different areas and attack any enemy. It will remain under the caster's control until it's destroyed in combat, unsummoned, or rest.
The golem gain a fighter's class and the same class level (up to 20) of its summoner. When a golem's class level increases, its abilities such as HP, THAC0 and save ability, also increase.
The golem's fist equals to +1 enchanted weapon at the begging, the fist gains +1 enchantment with every 5 levels of the summoner, and becomes a maximum +5 enchanted when the summoner reaches level 20.
Clay golem slows the enemy for 2 rounds on striking and being struck. The enemy needs to save vs. breath to avoid the effect. The slowing degree and the save penalty increases with its level. Besides this, it gains +1 to THAC0 for each 2 levels of itself.
The Necromancer can control only one golem at a time. The golem will not occupy the limited quantity of summoned units.
While on selection, golems switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Skeletal Mage (Necromancy)
Level: 3
Range: Visual sight of caster
Duration: 8 hours
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a skeleton mage with ranged elemental attack spell. When a skeleton mage is summoned, it randomly gains one type of element attack ability from fire, cold, electricity, acid and poison. The skeleton mage can follow the caster, remain in an area and attack any enemy. It remain animated until it's destroyed in combat, 8 hours pass, or turned.
The skeleton mages gain a wizard's class and a class level (up to 12) of +2 to half of their summoner. When a skeleton mage's class level increases, its abilities such as HP, spell level and save ability, also increase.
Spells casted by the skeleton mages are considered as 3rd-level arcane spells, which deal damage of 1D4 per 2 levels of the skeleton mages (such damage can be increased by high-level skills).
Casting frequency of skeleton mages may increase when they're affected by spells and skills that increase the number of attacks, such as haste and aura of Fanaticism.
While on selection, skeleton mages switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.
Manually operating a Skeleton Mage to cast spell on an enemy will give him a mark, and all Skeleton Mages will focus on the enemy within four rounds.

Blood Golem (Necromancy)
Level: 5
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a blood golem. The golem can follow the summoner across different areas and attack any enemy. It will remain under the caster's control until it's destroyed in combat, unsummoned, or rest.
The golem gain a fighter's class and the same class level (up to 20) of its summoner. When a golem's class level increases, its abilities such as HP, THAC0 and save ability, also increase.
The golem's fist equals to +1 enchanted weapon at the begging, the fist gains +1 enchantment with every 5 levels of the summoner, and becomes a maximum +5 enchanted when the summoner reaches level 20.
Blood golem has ability of draining life on attack, the amount of health points drained also increases with its level. Besides this, it gains +10 to max HP for each 2 levels of itself.
The Necromancer can control only one golem at a time. The golem will not occupy the limited quantity of summoned units.
While on selection, golems switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Iron Golem (Necromancy)
Level: 6
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a iron golem. The golem can follow the summoner across different areas and attack any enemy. It will remain under the caster's control until it's destroyed in combat, unsummoned, or rest.
The golem gain a fighter's class and the same class level (up to 20) of its summoner. When a golem's class level increases, its abilities such as HP, THAC0 and save ability, also increase.
The golem's fist equals to +1 enchanted weapon at the begging, the fist gains +1 enchantment with every 5 levels of the summoner, and becomes a maximum +5 enchanted when the summoner reaches level 20.
Iron golem has ability of return damage when hit by melee attack, and the amount of damage returned increases with its level. Besides this, it gains +1 to AC against all 4 types of weapons (Crushing, Missile, Piercing and Slashing) for each 2 levels of itself.
The Necromancer can control only one golem at a time. The golem will not occupy the limited quantity of summoned units.
While on selection, golems switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Fire Golem (Necromancy)
Level: 7
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a fire golem. The golem can follow the summoner across different areas and attack any enemy. It will remain under the caster's control until it's destroyed in combat, unsummoned, or rest.
The golem gain a fighter's class and the same class level (up to 20) of its summoner. When a golem's class level increases, its abilities such as HP, THAC0 and save ability, also increase.
The golem's fist equals to +1 enchanted weapon at the begging, the fist gains +1 enchantment with every 5 levels of the summoner, and becomes a maximum +5 enchanted when the summoner reaches level 20.
Fire golem appear with a Holy Fire aura, which adds fire damage on attack, and damages enemies in sight each round. Tho golem is immune to normal weapons and fire, and even restore some life when hit by fire attacks. When destroyed or unsummoned, it gives a small explosion which also damages nearby enemies. Besides this, it gains +1 to melee damage for each 2 levels of itself.
The Necromancer can control only one golem at a time. The golem will not occupy the limited quantity of summoned units.
While on selection, golems switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked. 

Revive (Necromancy)
Level: 7
Range: Visual sight of caster
Duration: 3 turns
Casting Time: 5
Area of Effect: 1 Creature
Saving Throw: Special
This spell applies a powerful curse to a creature. The target creature must save vs. spell or dies and be revived to undead. Category of revived creature is determined by its original race, some revived creatures even retain their spell ability and special ability. 
Revived creatures will remain under the caster's control and attack any enemy until it's destroyed in combat, unsummoned, or duration expires.
This spell affects undead and construct creatures as well, but can't affect targets beyond level 20. Creatures beyond level 20 or successfully save vs. spell will get part of the curse and lose 2 levels of experience.
While on selection, revived creatures switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Unsummon (Necromancy)
Level: 1
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 2
Area of Effect: 1 Creature
Saving Throw: None
The spell releases control of summoned creatures, makes them return to the places where they come from. The spell affects summoned creatures regardless of their alignment, but are not effective to planetars, devas and devils.


Poison and Bone Spells

Teeth (Necromancy)
Level: 1
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 2
Area of Effect: 30' cone with 120-deg. arc
Saving Throw: Half
When this spell is cast, it causes a cone-shaped area of teeth, originating at the wizard's hand and extending outward in a cone. It causes 1d4 points of damage per 2 levels of experience of the Necromancer and up to 10d4. With the increasing of caster's level, the density of dragon teeth also increases so that the enemy has more chance to be hit by several teeth (up to 3 hits) at the same time. A successful saving throw vs. spell reduces the damage to half. 

Bone Armor (Necromancy)
Level: 2
Range: 0
Duration: 12 hours
Casting Time: 2
Area of Effect: Caster
Saving Throw: None
When a Necromancer casts this spell upon himself, some pieces of bone armors circles around his body. The effect of bone armor is to protect the Necromancer from physical attacks. Bone armor will stop 3 physical attacks, and for each 5 levels of Necromancer, there're 3 more blocking chance (up to 15 at level 20). The armors will remain on the Necromancer until he is affected by a dispel magic, all of the armors are removed due to physical attacks or the spell duration expires. 

Poison Dagger (Necromancy)
Level: 2
Range: 0
Duration: 1 turn
Casting Time: 2
Area of Effect: Caster
Saving Throw: None
Any melee weapon on the caster's hand is poisoned when this spell is casted. Successful hits will inject the poison into the target, dealing out 2 damage every 2 levels per round, which lasts for 4 rounds. A saving throw vs. death with -2 penalty reduces the damage for half. The caster also gains a bonus of +1 to melee attack for every 2 levels (up to +10). Multiple casting of this spell are not cumulative.

Corpse Explosion (Necromancy)
Level: 3
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 3
Area of Effect: 1 Creature
Saving Throw: Special
This spell applies a powerful curse to a creature. The victim must save vs. spell or dies and gives an explosion of 15 feet in radius. All hostile creatures in the area of explosion will suffer 1d12 damage (half in fire and half in crushing, save vs. death for only 1d8 damage) per hit dice of the victim (5 hit dices at least). This spell affects undead and construct creatures as well, but can't affect targets beyond level 20. 
Creatures beyond level 20 or successfully save vs. spell will get part of the curse and -2 to all saves in 1 turn.

Bone Wall (Necromancy)
Level: 4
Range: Visual sight of caster
Duration: 1 round/2 levels
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This spell creates a pile of bones to block enemies. The bone wall persists in duration until it's destroyed. The wall gains 1 hit dice for each level of the Necromancer, and up to 20 hit dices.

Poison Explosion (Necromancy)
Level: 5
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 3
Area of Effect: 1 Creature
Saving Throw: Special
This spell applies a powerful curse to a creature. The victim must save vs. spell, or dies and gives an explosion, which creates a toxic cloud of 15 feet in radius, lasts for 4 rounds. All hostile creatures in the area will suffer 1d12 poison damage (save vs. death for half) for every 2 levels of the caster (up to 10D12) per round. This spell affects undead and construct creatures as well, but can't affect targets beyond level 20. 
Creatures beyond level 20 or successfully save vs. spell will get part of the curse and suffer 1d6 poison damage for every 2 levels of the caster.

Bone Spear (Necromancy)
Level: 4
Range: 30
Duration: Instantaneous
Casting Time: 2
Area of Effect: Special
Saving Throw: Half
Upon casting this spell, the Necromancer releases a bone spear that inflicts 1d12 points of magical damage per level of the spellcaster (maximum damage of 10d12) to each enemy within its area of effect. A successful saving throw vs. spell reduces this damage to half. 

Bone Prison (Necromancy)
Level: 5
Range: Visual sight of caster
Duration: 4 rounds
Casting Time: 4
Area of Effect: 1 Creature
Saving Throw: None
This spell applies a bone prison to trap enemy within its circumference. Imprisoned within a cage of bone, the captives suffer -5 penalty to attack and damage, 25% chance of spell failure, and are unable to move. Target's magic resistance will not interfere this spell.

Poison Nova (Necromancy)
Level: 6
Range: 0
Duration: Instantaneous
Casting Time: 5
Area of Effect: 30' radius
Saving Throw: Half
This spell generates a toxic cloud to poison hostile creatures within 30-foot radius. The victims lose 1 hit point per second for each 2 level of the caster (up to 10 hp per second) in 2 rounds. A successful saving throw vs. spell reduces this damage to half.

Bone Spirit (Necromancy)
Level: 7
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 3
Area of Effect: 1 Creature
Saving Throw: None
Upon casting this spell, the Necromancer releases a bone spirit that inflicts 1d20 points of magical damage per 2 levels of the spellcaster (maximum damage of 10d20) to target. No save is need for this spell.


Curses

Amplify Damage (Necromancy)
Level: 1
Range: Visual sight of caster
Duration: 2 rounds + 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
The spell allows the caster to adversely affect all the physical resistance of enemies. The effect is applied to all hostile creatures within the area of effect. Opponents under the influence of this spell make resistance of crushing, slashing, piercing and missile at a penalty of 50%. 
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

Dim Vision (Necromancy)
Level: 3
Range: Visual sight of caster
Duration: 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
When a Dim Vision spell is cast, hostile creatures within the area of effect become sightless. All of the effects of blindness apply to the victims such as a penalty to hit and to AC. The visibility range of the afflicted character is decreased as well. A successful saving throw vs. spell enables the creature to avoid the effect.
This curse will be overwritten when other curses are applied.

Weaken (Necromancy)
Level: 3
Range: Visual sight of caster
Duration: 2 rounds + 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
By means of this spell, a Necromancer weakens his opponents, reducing their Strength and thereby the attacks that rely upon it. The victims' strength will decrease 33% for the duration of the spell, unless a save vs. spell is made. The target receives all of the penalties for a lower strength such as attack and damage penalties as well as lower weight allowance.
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

Iron Maiden (Necromancy)
Level: 4
Range: Visual sight of caster
Duration: 2 rounds + 1 round/ 2 levels
Casting Time: 3
Area of Effect: 10' radius
Saving Throw: Neg.
When a Iron Maiden spell is cast on melee enemies, any damage they made will be reflected back to themselves. The damage monsters receive back increases for 1d6 piercing damage every 2 levels of the caster, up to 10d6.
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

Terror (Necromancy)
Level: 2
Range: Visual sight of caster
Duration: 1 round/ 2 levels
Casting Time: 3
Area of Effect: 10' radius
Saving Throw: Neg.
Terror empowers the caster to radiate a aura of fear out to a 10-foot radius. Hostile creatures within this aura must roll successful saving throws vs. spell or run away in panic. Affected individuals may even drop items.
This curse will be overwritten when other curses are applied.

Confuse (Necromancy)
Level: 5
Range: Visual sight of caster
Duration: 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
This spell causes confusion in hostile creatures within the area, creating indecision and the inability to take effective action. Those who fail their saving throws will either go berserk, stand confused or wander about for the duration of the spell. 
This curse will be overwritten when other curses are applied.

Life Tap (Necromancy)
Level: 4
Range: Visual sight of caster
Duration: 2 rounds + 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
This spell allows the Necromancer's allies to literally suck the life from their victims. A cursed creature gives health point of 1d6 / 2 caster levels to the attacker when struck, up to a maximum of 10d6.
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

Attract (Necromancy)
Level: 6
Range: Visual sight of caster
Duration: 4 rounds
Casting Time: 3
Area of Effect: 1 Creature
Saving Throw: Neg.
This spell causes hostile creatures in 30' radius to target one victim. They'll forget their previous purpose and attack the victim for 4 rounds if he fails saving vs. spell.
This curse will be overwritten when other curses are applied. This spell will not affect enemies beyond level 20. 

Decrepify (Necromancy)
Level: 6
Range: Visual sight of caster
Duration: 4 rounds
Casting Time: 3
Area of Effect: 10' radius
Saving Throw: Neg.
This curse gives the victim a glimpse of his own mortality, briefly aging the victim. Imagining itself with an infirm body of advanced age, the afflicted believes it is no longer capable of youthful exertions. Decrepify slows the speed, reduces the damage by 5 and makes enemies more susceptibile to physical damage by 25%. 
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

Lower Resist (Necromancy)
Level: 7
Range: Visual sight of caster
Duration: 1 round/ 2 levels
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Neg.
The spell allows the caster to adversely affect all the elemental resistance of enemies. The effect is applied to all hostile creatures within the area of effect. Opponents under the influence of this spell make resistance of fire, cold, electricity, acid and posion at a penalty of 10% + 1% per caster level (up to a maximum of 30% at level 20). For no EE games, the posion resistance is just set to zero.
Multiple castings of this curse are not cumulative. This curse will also be overwritten when other curses are applied.

*All spells that require Saving Throws have no penalty when cast by the Necromancer under level 10, yet for every 10 levels a -1 penalty to saves will be imposed. So when the Necromancer arrives LV50, his opponents should make save vs. spell with -5 penalty.

High-level skills

Skeleton Mastery
Enhance skeletons and skeletal magi with 1 HD and +1 bonus to AC, THAC0, damage and save ability. Can be selected 10 times in total. 

Golem Mastery
Enhance golems with 2 HD and +1 bonus to AC, THAC0, damage and save ability. Can be selected 10 times in total. 

Summon Resist
Give 10% elemental resistances of fire, cold, electricity, acid and poison to all summoned units of Necromancer. Can be selected five times in total. 

Revival Mastery
Enhance revived creatures with 2 HD and +1 bonus to AC, THAC0, damage and save ability, and give them an extra existing duration of 30 seconds. Can be selected 10 times in total. 

----------VERSION HISTORY----------

V0.8 A component is added for player to make choice whether a revived creature can follow the Necromancer across  different areas, as the following ability may cause lags and bigger non-EE games save files, which is not recommended when some amount of other MOD has been installed.
     Hot keys of summoned creatures are set to D (Defence) and N (Normalize). 
     Manually operating a Skeleton Mage to cast spell on an enemy will give him a mark, and all Skeleton Mages will focus on the enemy within four rounds.
     Skeletals and Skeletal Mages are no longer immune to some spells that cause instant death to summoned creatures, e.g. Cloud Kill and Death Spell. Golems and revived creatures are no longer immune to stun.
     Some summoned creatures voluntarily take one step away from the Necromancer when they get too close, in order to avoid getting jammed when traveling across different areas.
     Casting frequency of skeleton mages may increase when they're affected by spells and skills that increase the number of attacks, such as haste and aura of Fanaticism.
     All Curses now require Saving Throws, while some of them are given more powerful effects, such as Amplify Damage, Decrepify and Lower Resist.
     Bone Spear becomes a level 4 spell, while Poison Explosion becomes level 5. Adjusted damage and casting time of some Poison and Bone Spells.
     The lower limit of Corpse Explosion is set to 5D12, as some enemies in the game don't have correct class levels.
     Increased amout of high-level skills that avoids the problem of superfluous high-level skill points.
     Saving penalties of most spells are set to -1 per 10 levels of the Necromancer, up to -5 at LV50.
     Clay golem is able to slow the enemy (need to save vs. breath) on striking and being struck.
     All spells casted by the skeleton mages are considered as 3rd-level arcane spells.
     Adjustment of class levels and high-level skills of summoned creatures.
     AOE spells now ignore the protection of Mirror Image spell (EE only).
     Revival Mastery provides extra existing duration for revived creatures.
     No more Divine Spells in BG can be casted by the Necromancer.
     Fixed the wrong area of effect of Poison Explosion at high level.
     Fixed transparency of some animations for no EE games.
     Some spells now have corresponding animations.
     Fixed some mistakes of displayed text.
     Remaked all skill icons.
     Interactable with 'Jamella's Diablo2 Item Store' V2.0 or later, allowing to summon an Iron Golem with an Aura from one of the runeword weapons. Note that the Aura no longer appears when the Iron Golem dies or replaced by other golems, except that disappearing of the Iron Golem due to party rest does not mean a death and have no influnece on the Aura.

V0.7 A component is added to make the Necromancer able to cast Divine Spells in BG.
     Fix the problem that some summoned units are given worng names in BGEE.
     Summoned units are nolonger in a Level Drain state.
     Bone Walls are immune to Wing Buffet and Teleport Field.
     Skeleton and Skeletal Mage will nolonger be directly killed by Death Spell.
     Iron Maiden becomes a no-save spell.
     +1 enchantment to weapons of golems and skeletons.
     Faster HP Regeneration of summoned units.
     Revival Mastery give 2 class levels' enhancement each time instead of 1 class level.
     When selected, Golems, Skeletons and Skeletal Mages can enter an inactive mode by press C, and quit the mode by press C again. In the inactive mode, they'll not attack enemies initiatively unless get closed and attacked by them.

V0.6 Supports EE and original BG2. Unsuperposable Necromancer spells in EE is treated as official spells: the later casted spell directly replace the previous one; while in original BG2, a later spell can only be wasted before the expiring of a previous one.
     A component is added to extend level limits of Revive, Corpse Explosion, Poison Explosion and Attract to LV.32 for players of Legacy of Bhaal mode.
     Necromancer's minions are immune to poison and poison damage.
     Revive will drain 2 levels of experience for creatures beyond level limit or successfully save vs. spell.
     Attract will bring a penalty of -2 AC for creatures beyond level limit or successfully save vs. spell.
     Corpse Explosion will bring a penalty of -2 to saves for creatures beyond level limit or successfully save vs. spell.
     Each piece of Bone Armor gain one more blocking chance for each 5 levels of Necromancer.
     Save penalty of some spells will be enhanced as Necromancer's level increases.

V0.5 Fixed the problem that Fire Golem damages party members continuously after death.
     Enhanced Revive, Corpse Explosion and Posion Explosion: some effects for creatures beyond level 20 or successfully save vs. spell.

V0.4 Fixed the problem of wrong summoning of skeleton mage at low and high level.

V0.3 Fixed the problem of game crash when summoning Fire Golem at high level.
     Skeleton Mastery and Golem Mastery enhances creatures with 2 level per choice.
     Priest spell slots penalties are cancelled because they may cause some problem.
     Give another 3D Effect to Dim Vision because the old one often displays as half of a full graphic.

V0.2 Fixed the AI problem of summoned creatures caused by conflict with some tactics MODs on using of extra weapon proficiency.
     Bone Wall becomes three piles of bones, each of them has less HP than before.

V0.1 Finished the Necromancer kit.