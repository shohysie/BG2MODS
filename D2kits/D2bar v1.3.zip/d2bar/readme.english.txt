/////////////////////////////////////////////////////
/////Diablo2 Kit Pack - The Barbaian Ver 1.3/////////
/////////////////////////////////////////////////////

----------ATTENTIONS----------

  It is a Fighter kit for BG2, BGT and EE series.

  Barbarian gains one 'Skill Point' each level until 3,000,000 exp, player can get one skill that you like to learn by consuming each 'Skill Point'.
  *If you do press a 'Skill Point' at skill table but then close the arisen skills table without making a choice, the 'Skill Point' does nothing by get wasted!
  Many powerful skills do not appear at low level. Maybe you'd store the 'Skill Points' up to high level to purchase much powerful skills.

    There's an extra component 'Allow the Barbarian(D2) to use a Two-handed Sword with one hand' which is adviced to be installed after all MODs that bring new weapons. Reinstall of such component alone also provides support for new 2-handed swords added later, but is not recommended.
    Equip the two-handed sword in hand and then click on Mode Switching button at skill table, the sword switches to one-handed mode, its Proficiency Type also changes to Bastard Sword. The switched sword can only be used by a Diablo2 Barbaian.
    With a sword that switched to one-handed mode in hand, cast Mode Switching again and the two-handed sword comes back. (In no EE games, in order to avoid game crushing, such switching is ineffective when there's something in offhand.)

----------KNOWN BUGS----------

  Barbarian's combat skills may get problems in case that MOD items which have immunity from 'Removal: Remove Secondary Type' are equipped. 
  This bug does not exist in EE games.

  If there're several Diablo2 Barbarians in your team, and they're all equiped with switchable swords, Mode Switching skill only works on the first Barbarian. You can give the switched sword to other Barbarians.

----------DETAILED DESCRIPTION----------

Barbarian
The Barbarian, a member of any of several tribes on the fringes of civilization, rebuffs the influence of those he sees as soft and weak. Ceaseless clan warfare and the constant struggle to survive in the hostile wilderness are evident in the Barbarian's sturdy and powerful frame. Though perhaps lacking the sophistication of his civilized contemporaries, the Barbarian has an acute awareness of his surroundings. Because of his shamanistic belief in the animal powers with whom he identifies, the Barbarian is sometimes associated with stories of lycanthropy. In fact, he believes that he can improve his superb battle tactics by calling upon the totemic animal spirits to infuse him with supernormal strengths and abilities. 

Advantages:
- Has a D12 Hit Die instead of D10.
- Get bonus of +1 to strength and vitality on character creation.
- Can use a Two-handed Sword with one hand through a mode switching skill.
- Three skill trees: Warcries, Combat Masteries and Combat Skills.

Disadvantages:
- Get penalty of -2 to intelligence and charisma on character creation.
- May not learn high-level skills of original fighters.
- Only can be proficient in bow and crossbow.
- Only can be master in weapons except bow and crossbow.
- Unable to dual class.


Warcries

Howl
A Barbarian warrior in battle is a fearsome enough sight. They cover their bodies with strange markings and the fire in their eyes can be seen from across a battlefield. Early in his training a warrior must learn how to tap the primal energies around him and utter a howl in battle-a bellow so fierce that it will send even the battalions of the Burning Hells running in fear.
This skill makes enemies in 30' radius run in fear, requires saving vs. breath. Enemies over Level 20 will not be affected. Can be learned at LV1.
  LV1: save with -1 penalty, 2 rounds; LV5: save with -2 penalty, 4 rounds; LV10: save with -3 penalty, 6 rounds; LV15: save with -4 penalty, 8 rounds.

Find Potion
When a warrior is injured while out in the field, he must find ways to effectively heal wounds. By picking among the glands and entrails of the recently dead, a Barbarian warrior can sometimes scavenge enough ingredients to make a powerful healing elixir. Some Barbarians are skillful and fortunate enough to find ingredients for a potion that restores not only their health but their spirit as well. 
This skill increases chance of finding potions after kill each enemy. Duration: 1 round. Can be learned at LV1.
  LV1: potion of healing/antidote/potion of defense/other potions; LV5: potion of healing/antidote/potion of stone form/potion of heroism/other potions; LV10: potion of extra healing/elixir of health/potion of invulnerability/potion of heroism/other potions; LV15: potion of super healing/elixir of health/potion of invulnerability/potion of power/other potions.
 *Find Potion and Find Item can not take effect at the same time.

Shout
Barbarian warriors are born to command in battle. When a warrior learns this skill he can raise his voice above the din of combat to shout warnings of impending blows to his comrades in arms. This will alert them in time to allow them to guard against the incoming attack. 
This skill gives an AC bonus to friendly creatures in 30' radius. Can be learned at LV5.
  LV5: +3 AC bonus, duration: 1 turn; LV10: +4 AC bonus, duration: 2 turns; LV15: +5 AC bonus, duration: 3 turns; LV20: +6 AC bonus, duration: 4 turns.

Taunt
Pinpointing an opponent's physical weakness is not the only talent a warrior of the Steppes possesses. He can often ascertain what emotional weakness might allow the barbarian to goad an opponent into a fight. A Barbarian taunting an opponent into a blind rage hopes to capitalize on the mistakes enemies may make while so angered. It is this ability that causes Barbarians to have a poor reputation as drinking partners. 
This skill defiances an emeny, who temporarily forgets his spells and skills, to fight you with melee attack. Requires saving with spells. Enemies over Level 20 will not be affected. Duration: 4 rounds. Can be learned at LV5.
  LV5: -2 penalty to enemy's THAC0 and damage, requires saving with +1 bounce; LV10: -4 penalty to enemy's THAC0 and damage, requires saving with no bounce or penalty; LV15: -6 penalty to enemy's THAC0 and damage, requires saving with -1 penalty; LV20: -8 penalty to enemy's THAC0 and damage, requires saving with -2 penalty.
 *Do NOT cast this skill on friendly creatures.

Find Item
To most people, searching the bodies of the recently slain is a distasteful chore. Quite happy with procuring whatever items are readily visible and moving on, most people often miss useful items. The Barbarian people have never had the luxury of abundance, and their harsh existence has taught them to scavenge every part of the dead for the items they need to survive. What use do the dead have of gold? 
This skill increases chance of finding items after kill each enemy. Duration: 1 round. Can be learned at LV10.
  LV10: normal equipments/100 gold/cheap gems; LV15: +1 equipments/200 gold/lower gems; LV20: +2 equipments/400 gold/gems; LV25: +3 equipments/800 gold/costly gems.
 *Find Potion and Find Item can not take effect at the same time.

Battle Cry
Gifted Barbarian warriors can benefit from their connection to their totem animals to exploit the primal fears of their opponents. Once a Barbarian unleashes the Battle Cry, even the legions of the dead will become so distracted that they falter in their quest for victory. This permits the warrior an easy kill. 
This skill lowers enemy's defense and damage in 30' radius. Can be learned at LV15.
  LV15: -4 bouns to AC and damage, duration: 4 rounds; LV20: -5 bouns to AC and damage, duration: 6 rounds; LV25: -6 bouns to AC and damage, duration: 8 rounds; LV30: -7 bouns to AC and damage, duration: 10 rounds.

Battle Orders
Although skillful in single combat, the Barbarian warrior also has a talent for group tactics. It is this ability that makes him a natural leader in combat. An experienced warrior can use this skill to better array his forces in battle, enhancing their ability to overcome the enemy. 
This skill increases maximum HP of friendly creatures in 30' radius. High-level skill.
  Before LV25: +40% max HP, duration: 2 turns; LV25: +50% max HP, duration: 3 turns; LV30: +60% max HP, duration: 4 turns; LV35: +70% max HP, duration: 5 turns; LV40: +80% max HP, duration: 6 turns.

Grim Ward
This skill allows the Barbarian to fashion a totem out of the carcass of his slain enemies. The resulting talisman serves as a grave warning to all of the minions of the Prime Evils. The mere sight of the Totem causes monsters to flee in terror. With additional training the warrior can increase the potency of the ward. 
This skill summons a fetish that will frighten enemies to 30' radius away, duration: 30 seconds. High-level skill.

War Cry
Summoning the ancient powers known to his people, a Barbarian warrior can call on his spirit animal and lash out at his enemies with a cry that halts them in their tracks-a powerful anguish rising to burn the depths of their being. It is this skill that gives rise to the legends of Barbarians being able to sap the life from a creature with a single word. 
This skill damages and stuns your enemies in 20' Radius, successfully saving vs. breath will reduce the damage and stunned length to half. High-level skill.
  Before LV25: 2D4 damage, stuns for 2 seconds; LV25: 2D6 damage, stuns for 3 seconds; LV30: 2D8 damage, stuns for 4 seconds; LV35: 2D10 damage, stuns for 5 seconds; LV40: 2D12 damage, stuns for 6 seconds.

Battle Command
Using this skill a Barbarian can examine the abilities of his companions and, during battle, determine how best the group should apply their various skills. It is this skill as well as their natural abilities as leaders that are gradually shedding the long held stereotype that the Barbarian people are merely ignorant savages. 
This skill increase all saves, THAC0, AC, damage, casting speed and attack speed by 1 for friendly creatures in  30' Radius. High-level skill.
  Before LV25: 2 turns; LV25: 3 turns; LV30: 4 turns; LV35: 5 turns; LV40: 6 turns.

Combat Masteries

Increased Stamina
The tribes of the northern Barbarians are a nomadic people, roaming the vast open plains of the Northern Steppes. Being raised in this environment has strengthened the Barbarian people. Simply by looking at a member of the northern clans, you can tell that they are more hale and hearty than the average person. Such is their vigor! Through strict conditioning, the Barbarian warriors can train their bodies to endure tremendous physical exertions, and at a moments notice can be ready for battle. 
With this skill, Barbarian will infrequently get tired. He will also be immune to negative effect of spells such as Haste and Restoration. Gets in LV10.

Increased Speed
It is a fatal assumption that the Barbarian warrior is slow and ponderous. His great bulk belies a very agile individual. A lifetime of patrolling the vast plains of his native soil, where it is often necessary to cover great distances in very little time, has empowered the Barbarian warriors with the ability to walk and run at surprising rates of speed. 
This skill Permanently increases Barbarian's walk speeds, +1 bonus on start, then in LV5, LV10, LV15 and LV20.

Iron Skin
The harsh grasslands of their homeland offer the Barbarian people little refuge from the elements. Constant prolonged exposure to the sun, wind, rain and other elements has toughened their skin to the resilience of natural leather. 
This skill permanently gives +2 bonus to AC and 10% resistance to physical damage in LV15, LV20, LV25 and LV30.

Sword Mastery
Although there are many gifts from the Great and Ancient King Bul-Kathos, the greatest of these is the secret of steel. Raw iron is hardened and made resilient, forged into weapons of honor and power. Most mortal swords are patterned after the blade first wielded by Bul-Kathos himself. Balancing offense with defense, it is the perfect weapon for the defense of Mount Arreat in the coming apocalypse. All Barbarian warriors learn the secrets of steel at an early age, yet few truly master the deadly elegance of the sword. Those few who do often disdain all other weapons. 
This skill provides maximum proficiency (5 points) in sword (short sword, long sword, bastard sword and two handed sword) style. High-level skill.

Axe Mastery
Barbarian warriors of the Shadow Wolf Tribe are masters of the axe. Through the axe, they sought to match the swiping claws and the biting teeth of the wolves with which they lived and fought beside. These first axes were but crude stones mounted on wooden hafts, and after learning the secret of steel and swords from Bul-Kathos, the axe soon fell into disfavor. Recently, however, warriors and smiths from the Steppes have perfected the axe as a weapon equal to or greater than the sword. The Wolf Tribe once again teaches the swift and terrible power of the axe to those who wish to learn how to cull the weak from the herd and to protect their pack from the legions of Hell. 
This skill provides maximum proficiency (5 points) in axe style. High-level skill.

Mace Mastery
Barbarians who have quested with the mighty Bear Tribe are masters of the Mace. From simple wooden clubs to the contemporary, armor-defeating flanged mace, warrior masters wield these weapons to devastating effect. As the Bear shaman, Koth, said to those who favor the sword and axe, 'When you are beset by hordes of the walking dead, do not come weeping to me if you have turned away from the wisdom of Bear.' 
This skill provides maximum proficiency (5 points) in mace (mace, war hammer, flail and club) style. High-level skill.

Polearm Mastery
Members of the Crane Tribe value distance, grace and a single overwhelming blow over the close grappling form advocated by the Bear Tribe. Though the two clans were wary of one another for many generations, recently the nomadic peoples have commingled and now share their powerful techniques with all that would learn. Crane warriors evolved their pole arm technique from dealing with mounted raiders and fighting in the shallow river waters found in the steppe. A master of the pole arm avoids physical contact with his opponent until he can land a single killing blow. 
This skill provides maximum proficiency (5 points) in polearm (halberd, spear and staff) style. High-level skill.

Throwing Mastery
Although not as well known for their use of bows and other such ranged weapons, hunters from the Steppes have practiced the use of thrown weapons since earliest times. The open grasslands of their native soil are well suited for taking down game with swift and accurate blows from a hurled blade. It seems a natural evolution and a simple matter for them to have transferred this skill to combat. 
This skill provides maximum proficiency (5 points) in throwing (dart and sling) style. High-level skill.

Blade Mastery
Warriors of the Tiger Tribe like to imitate the way tigers use their claws in battle. They are good at wielding their blades to unleash swift and violent attacks, causing fatal damage to their enemies. 
This skill provides maximum proficiency (5 points) in blade (dagger, scimitar and katana) style. High-level skill.

Natural Resistance
In order to survive the unforgiving lands of the north, the people of the Barbarian tribes have developed hardy resistances to the common elements. Heat and cold alike are something they endure often. Since food is scarce while foraging, they have learned to consume species of plants that would slay normal men. Through additional training, a warrior can further fortify himself against these dangers, allowing him to better survive while traveling to unfamiliar lands and battling unknown foes. 
This skill increases resistances to elemental damage by 15%, and make Barbarian immune to poison. Can be chosen for 4 times. High-level skill.


Combat Skills

Bash
The immense physical strength of the Barbarian people is widely known, so it should come as no surprise that this is one of the first skills that they develop as a warrior. Summoning up their renowned brute strength a Barbarian can deliver a powerful and painful blow that staggers an enemy from its feet, knocking them back. 
This skill provides a powerful smashing blow (melee only) that knocks the target back, requires saving vs. death. Duration: 4 rounds. Can be learned at LV1.
  LV1: +1 to melee damage, +1 to melee THAC0, knock back with -1 save penalty; LV5: +2 to melee damage, +2 to melee THAC0, knock back with -2 save penalty; LV10: +3 to melee damage, +3 to melee THAC0, knock back with -3 save penalty; LV15: +4 to melee damage, +4 to melee THAC0, knock back with -4 save penalty.

Double Swing
A Barbarian warrior learns to fight with a weapon in each hand, for after all, are not two weapons better than one? A young Barbarian learns to use both hands independently of each other, striking simultaneous blows at separate targets. As his talent grows in this skill, he attacks with increasing control and accuracy. 
This skill enhances two weapon fighting in 4 rounds, and will automatically repeat casting itself in battle, until losting target for 4 rounds, or another combat skill, which can no work together with Double Swing, is casted. Can be learned at LV5.
  LV5: temporarily get 2 points proficiency in two weapon fighting style, +1 to melee THAC0 and +1 extra THAC0 with off hand; LV10: temporarily get 3 points in two weapon fighting style, +2 to melee THAC0 and +1 extra THAC0 with off hand; LV15: temporarily get 3 points in two weapon fighting style, +3 to melee THAC0 and +2 extra THAC0 with off hand; LV20: temporarily get 3 points in two weapon fighting style, +4 to melee THAC0 and +2 extra THAC0 with off hand.

Leap
Because of his great strength, a trained barbarian warrior is able to perform great leaps. These jumps are noteworthy, enabling the Barbarian to spring free of dangerous swarms of enemies, and landing with an impact that sends them reeling. 
This skill makes a leap (teleportation) landing with an impact. Can be learned at LV5.
  LV5: 20' leap distance, 10' radius impact; LV10: 30' leap distance, 20' radius impact; LV15: 40' leap distance, 30' radius impact; LV20: 50' leap distance (equivalent to range of visibility), 40' radius impact.

Double Throw
To a Barbarian, fighting with two weapons is considered a fairly simple feat. Not so simple is mastering the art of throwing two weapons simultaneously and accurately. Many young Barbarians are eager to learn this skill, for they will tell you it is concrete proof that they have risen to greatness as a warrior. In truth, they use this skill in tavern games almost as often as they do in battle, winning wagers from unsuspecting drunkards. 
This skill provides +1 attack per round while using ranged weapons (triggered on hitting). Duration: 4 rounds. Can be learned at LV10.
  LV10: +2 to range THAC0; LV10: +4 to range THAC0; LV15: +6 to range THAC0; LV20: +8 to range THAC0.

Stun
An experienced Barbarian can learn to strike an opponent in areas that promote the maximum effect. By putting enough strength behind a well-placed blow, he can leave an opponent dazed and unable to strike back or flee. 
This skill makes melee attacks able to stun an enemy, requires saving vs. death. Duration: 4 rounds. Can be learned at LV10.
  LV10: +1 to melee THAC0, stuns for 1 seconds with -1 save penalty; LV10: +2 to melee THAC0, stuns for 2 seconds with -2 save penalty; LV15: +3 to melee THAC0, stuns for 3 seconds with -3 save penalty; LV20: +4 to melee THAC0, stuns for 4 seconds with -4 save penalty.

Leap Attack
A young treasure hunter once sought his fortune in a raid for Barbarian gold on Mount Arreat. Hearing tales of the Barbarian people's expertise in close combat, he hired a phalanx of mercenary spearmen to accompany him, thinking their long spears would force the Barbarian warriors to fight from a distance. He soon learned his mistake as a single Barbarian warrior was enough to slaughter his entire party. Ambushing the raiding party from a patch of scrub grass, the Barbarian leapt over them, slaying one whilst airborne, and skewering two more as he landed. Before the would-be thief could draw a single breath, all of his hired lancers had been dispatched. It was a long walk home. 
This skill makes a leap (teleport) onto a target with an attack on landing. The victim may make a save vs. death in order to take only half damage. Can be learned at LV15.
  LV15: 6D10 damage; LV20: 8D10 damage; LV25: 10D10 damage; LV30: 12D10 damage.

Concentrate
Sometimes a series of blows is not nearly as effective as a single, concentrated strike. A Barbarian trained in this skill learns how to focus his strength into a single blow that cuts through the guard of an enemy and slices through their armor. This technique also puts the warrior in a superior defensive position. 
This skill ensures an uninterruptible attack, which temporarily improves your defense and gives you immunity to threatening influences such as charm, stun, fear, sleep and confusion. Duration: 4 rounds. Can be learned at LV15.
  LV15: +2 to damage and AC bonus, +3 to hit; LV20: +3 to damage and AC bonus, +4 to hit; LV25: +4 to damage and AC bonus, +5 to hit; LV30: +5 to damage and AC bonus, +6 to hit.

Frenzy
Although a Barbarian is capable of calculated blows and tactical fighting techniques, it is his fierce passion for battle that distinguishes him in battle. While using this skill, a Barbarian drives more and more force into each successive blow as his anger and bloodlust mounts. 
In the 1 round's skill duration, each successful attack brings Improved Haste to the Barbarian, and improves his attack frequency and movement rate (up to 10 attacks per round and +10 to movement rate) as well. While Frenzy expires, the state of increased attack frequency and movement rate remains for 1-2 rounds, which may work with other Combat Skills. High-level skill.
  LV20: +2 to hit, +2 to damage; LV25: +3 to hit, +3 to damage; LV30: +4 to hit, +4 to damage; LV35: +5 to hit, +5 to damage; LV40: +6 to hit, +6 to damage.

Whirlwind
Of the Barbarian people, the Tribe of Thunder was the first to draw upon the primal forces of the weather. Tornadoes would ravage their plains as summer turned to the harvest season. The shaman of the tribe would interpret the tornadoes as an omen of evil during times of peace, and as a harbinger of great victory during wartime. Observing the strength of the whirlwind, these Barbarians learned to emulate the swirling melange of the cyclone in their attacks. As time went on and the tribes intermingled, the ability to attack in the manner of the whirlwind was passed down to all of the Barbarian people. 
This skill makes multiple attacks while spinning through enemies, the victim(s) may make a save vs. death in order to take only half damage. Duration: 6 seconds, attack radius: 10'. High-level skill.
  LV20: 12D4 damage per second; LV25: 12D4+6 damage per second; LV30: 12D4+12 damage per second; LV35: 12D4+18 damage per second; LV40: 12D4+24 damage per second.

Berserk
There is a fine line between passion and rage, something the Barbarian warrior knows well. A Barbarian must learn to tread this line while separating one from the other and drawing strength from both. One of the most powerful combat skills a Barbarian can learn is to cross that line into rage, expending the sum of his energy and slaying everything without regard for consequences. When you have slain all of your enemies, what is left to fear? 
This skill provides a powerful attack that leaves the Barbarian more vulnerable, with a AC penalty of 20. Duration: 1 round, may take effect together with other Combat Skills. High-level skill.
  LV20: +4 to hit, adds 4D8 magic damage; LV25: +5 to hit, adds 5D8 magic damage; LV30: +6 to hit, adds 6D8 magic damage; LV35: +7 to hit, adds 7D8 magic damage; LV40: +8 to hit, adds 8D8 magic damage.

*Bash, Double Swing, Double Throw, Stun, Concentrate and Frenzy can not take effect together with each other. Each of them will directly replace a pre-casted one.

----------VERSION HISTORY----------

V1.3 An extra component gives the Barbarian ability to use a Two-handed Sword with only one hand. The component is adviced to be installed after all MODs that bring new weapons. Reinstall of such component alone also provides support for new 2-handed swords added later, but is not recommended.
   Fixed the problem that Shout, Battle Commands and Battle Command give strange words.

V1.2 Fixed the problem that the Barbaian can keep invisible on casting some attack skills.
   More stunned duration of War Cry but requires save. with breath.
   More kinds of items can be found with Find Item, including magic scrolls and some unique items.

V1.1 Fixed animation bugs of Warcries.
   All the casting time of Warcries is set to 2.
   Some skills now have sounds and animations.
   Corrected the level restrictions of Howl and Taunt, such restrictions can be extended to LV32 with an extra component.
   Rebuild the Frenzy skill to fix all the problems.
   Improved the damage Dice of Berserk from d8 to d10.
   Barbaian's AOE skills now ignore the protection of Mirror Image spell (EE only).
   No more free moving and attacking on casting Whirlwind.
   Passive skills such as Increased Stamina, Increased Speed and Iron Skin are directly applied to Barbaian at proper levels, rather than getting new skill buttons.
   Added skill descriptions from original Diablo2.

V1.0 Increased Speed only +1 bonus to walk speed per skill level.
   Find Potion can create Small Rejuvenation Potions and Full Rejuvenation Potions with a chance of less than 1%. Small Rejuvenation Potion recover 35% HP and recall 1 spells per spell level, Full Rejuvenation Potion recover 100% HP and recall all spells and skills.
   Cancelled the level limit of Howl.
   Iron Skin provides +2 AC bonus per level.
   Fixed the bug that Double Swing does not automatically repeat casting itself.
   Blade Mastery also gives proficiency in dagger.

V0.9 Spear Mastery is replaced by Blade Mastery, which gives proficiency in blade style including scimitar and katana. Proficiency in spear is integrated into Polearm Mastery.
   Find Potion can create some other potions.

V0.8 Supports EE and original BG2. Unsuperposable Barbaian skills in EE is treated as official spells: the later casted spell directly replace the previous one; while in original BG2, a later spell can only be wasted before the expiring of a previous one.
   Can wear plate and full plate armor now, but nolonger immune to backstab.
   The bug of several buttons of 'Increased Speed' vanish with one click when starting game in TOB, is fixed.
   Effects and save penalties of some skills are adjusted.
   Warcries, Leap and Leap Attack become slower.
   Leap has a distance limit at low level.
   Howl and Taunt now work on enemies with higher level than the barbarian, but still has a limit of level 20. A component of no level limit is supplied for players of difficult MODs.
   The bug of Frenzy cause a decline of attacks per round after 5 attacks is fixed. It's also enhanced to a easy achieving of 10 attacks per round.
   Some skills that can stun enemies also gain ability of pause enemies, which may affect enemies that immune to stun.

V0.7 The problem that some skills disappear with Ctrl+R is fixed.
   Adjusted damage of Leap Attack, Whirlwind and Berserk.
   Adjusted Max HP of Battle Orders.
   The Barbaian now can be master in weapons except bow and crossbow.
   Five Skill Point can be obtained after 3,000,000 exp from interface of choosing High-Level skills.

V0.6 Effects of Howl and Taunt get a little advance, yet the skills also get level restrictions.

V0.5 Remaked all skill icons.

V0.4 Weakened the Taunt skill, enhanced the Double Swing skill. Traditional Chinese version added.

V0.3 Fixed the mode of getting and casting skills: gain one 'Skill Point' each level until 20, player can gain one skill that you like to learn by consuming each 'Skill Point'.

V0.2 Tried to challenge a perfect mode of getting and casting skills, but failed. Unreleased version.

V0.1 Finished the Barbaian kit.