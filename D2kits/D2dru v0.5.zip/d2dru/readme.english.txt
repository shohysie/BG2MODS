/////////////////////////////////////////////////////
///////Diablo2 Kit Pack - The Druid Ver 0.5//////////
/////////////////////////////////////////////////////

----------ATTENTIONS----------

    It is a Druid kit for BG2, BGT and EE series.
    Only one Druid(D2) is suggested in a whole game, as multiple Druids' high-level skills and animals will be in conflict.

    While on selection, vines, wolves and grizzly switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.
    Vines, spirits and grizzly do not occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned. If they are imprisoned or petrified, a reverse magic is required to free them, or else they can't be summoned again.
    Summoned creatures may lose some ability bonus when game is saved and loaded at the instant that summoning spell is just casted successfully.  

----------KNOWN BUGS----------

    On entering some special areas, e.g. the third level of Watcher's Keep, summoned creatures that can follow the summoner across different areas may be lost behind. Try entering again to bring them along.
    Molten Boulder, Twister and Tornado always appear on top-left of the caster, its flying road will be blocked by the caster's body when casted towards down-right. You can manipulate the character to move and leave a road for them. 
    As the Infinity Engine has some problem on Level Modifiering, some of the summoned creatures do not have correct levels, which may cause a few incorrect attributes.
    Some skills and spells may be conflict with MOD items which have immunity from 'Removal: Remove Secondary Type'. Such problem does not exist in EE games.

----------DETAILED DESCRIPTION----------

Druid
    The Druids are a race of nomadic warrior-poet-kings. Driven from their homelands long ago by their Barbarian brothers��the Druid tribes live primarily in the northern forests. Using mystic secrets passed down through the generations��they summon the elements of fire and wind to do their bidding��and command the creatures of the forest to aid them in battle. Shifting from their human forms into that of wild beasts��gives them abilities far beyond those of other mortals.

Advantages:
- New druid spells and high-level skills: Elemental Spells, Shape Shifting and Summoning.
- Get bonus of +1 to wisdom on character creation.

Disadvantages:
- May not learn spells and high-level skills of original druids.
- Cannot cast Elemental Spells except the Armageddon while in Werewolf or Werebear form. 
- Unable to dual class.


Elemental Spells

Firestorm (Invocation)
Level: 1
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 1
Area of Effect: 30' cone with 90-deg. arc
Saving Throw: Half
Wielding this spell, the Druid projects waves of molten earth that spread outward and burn a wide swath of destruction through his foes. It causes 1d4 points of fire damage per 2 levels of experience of the Druid and up to 10d4. All enemies in the area of effect must save vs. spell for half damage.

Molten Boulder (Invocation)
Level: 3
Range: Visual sight of caster
Duration: 1 round
Casting Time: 2
Area of Effect: Special
Saving Throw: Half
By virtue of this talent, a Druid can summon forth a huge, rolling mass of magma, bowling over smaller enemies in its path before bursting into fiery shards. The boulder pushes emenies away on its route and hurts them (1d6 fire and 1d6 crushing damage per 4 levels of experience of the Druid, up to 5d6 + 5d6). The boulder also leave a burning tail which lasts for 3 seconds and causes fire damage (1d6 fire damage per 4 levels of experience of the Druid per second, up to 5d6) on emenies who dare to step foot in. A successful Saving Throw vs. spell reduces the fire damage to half.

Arctic Blast (Invocation)
Level: 2
Range: Visual sight of caster
Duration: Special
Casting Time: 1
Area of Effect: Special
Saving Throw: Half
Aided by the will of the North Winds, the Druid conjures up a chilling torrent of frost that incapacitates all caught within the frozen blast. It affects continuously in a short duration and deals damage for several times, which makes 1d4 points of cold damage per second per 4 levels of experience of the caster (up to 5d4) each time and slow the enemy for 1 second + 1 second per 4 levels of the caster (up to 6 seconds).  Successfully saving vs. spell will reduce the cold damage and length to half.

Fissure (Invocation)
Level: 4
Range: Visual sight of caster
Duration: 1 round
Casting Time: 2
Area of Effect: 15'
Saving Throw: Half
Sending his plea to the very core of the earth, the Druid rends the earth's very crust, tearing open volcanic vents beneath the feet of his adversaries, charring them to the bone. The lava causes 1d8 points of fire damage per second per 4 levels of experience of the caster (up to 5d8), yet enemies in the effective area have 50% chance to avoid each hit. Successfully saving vs. spell will also reduce the fire damage to half.

Cyclone Armor (Invocation)
Level: 5
Range: 0
Duration: 1 turn/level
Casting Time: 3
Area of Effect: Caster
Saving Throw: None
This spell allows the Druid to sheath himself in a swirling mass of charged particles that absorbs damage from all element attacks. All resistance of the caster will be set to 75%. 
This spell ignores Dispel Magic but can be breached by magic attack spells such as Pierce Shield.

Twister (Invocation)
Level: 4
Range: Visual sight of caster
Duration: 1 round
Casting Time: 2
Area of Effect: Special
Saving Throw: Half
Calling to the winds, the Druid sends small whirlwinds advancing into the midst of his enemies, buffeting and stunning them as they go. Each whirlwind causes 1d4 points of crushing damage per 4 levels of experience of the caster (up to 5d4) and stun enemies for 1 second. Successfully saving vs. spell will reduce the damage to half and avoid being stunned.

Volcano (Invocation)
Level: 6
Range: Visual sight of caster
Duration: 2 rounds
Casting Time: 3
Area of Effect: 30'
Saving Throw: Half
A Druid trained in this ability possesses the power to summon from the bowels of the earth a violent eruption, raining molten rock down upon all nearby foes. Volcano causes 1d6 points of fire damage per 2 seconds per 4 levels of experience of the caster (up to 5d6) and the same crushing damage, yet enemies in the effective area have 50% chance to avoid each hit. Successfully saving vs. spell will also reduce the damage to half.

Tornado (Invocation)
Level: 5
Range: Visual sight of caster
Duration: 1 round
Casting Time: 2
Area of Effect: Special
Saving Throw: Half
Manipulating the great winds into a fearsome cyclone, the Druid sends this force of destruction into a throng of opponents, crushing into them and leaving devastation in its wake. Tornado causes 1d12 points of crushing damage per 4 levels of experience of the caster (up to 5d12). Successfully saving vs. spell will reduce the damage to half.

Hurricane (Invocation)
Level: 7
Range: 0
Duration: 10 seconds + 2 seconds / 2 levels
Casting Time: 4
Area of Effect: 15'
Saving Throw: Half
Particularly talented Druids can summon this most potent gale of devastation. A fierce storm wreaks havoc around him, while the Druid stays cradled within the gentle calm of its eye. Hurricane strikes every 2 seconds, each attack causes 1d4 points of cold damage per 4 levels of experience of the caster (up to 5d4) and slows enemies for 2 seconds. Successfully saving vs. spell will reduce the damage and slowed duration to half.
Hurricane and Armageddon do not work together.

Armageddon (Invocation)
Level: 7
Range: 0
Duration: 10 seconds + 2 seconds / 2 levels
Casting Time: 5
Area of Effect: Special
Saving Throw: Half
This terrible force of nature's vengeance rains down flaming stones around the Druid who cast it, pummeling any opponents foolish enough to be caught in its fury. Each meteor causes 1d6 fire damage per 2 levels of experience of the caster (up to 10d6) and 1d10 points of crushing damage. Successfully saving vs. spell will reduce the damage to half.
Armageddon can be casted while in Werewolf or Werebear form. Hurricane and Armageddon do not work together. 

*The Druid spells have -1 save penalty when caster reaches level 10, and for every 10 levels a -1 to saves will be imposed until level 50.


Shape Shifting

Werewolf (Transmutation)
Level: 1
Range: 0
Duration: 1 turn / level
Casting Time: 1
Area of Effect: Caster
Saving Throw: None
This ability allows an enlightened Druid to take on the form of a wolf, imparting to him quicker reflexes and heightened combat facilities. The caser temporarily gains +2 to maximum HP per level (up to +30 to maximum HP at level 15). He also obtains +2 bonus to melee THAC0 and +0.5 attack per round, which is a repeatable bonus to obtain on each 5 levels (up to +8 bonus to melee THAC0 and +2 attacks per round at level 15). 

Lycanthropy
Changing shape is quite a taxing ordeal for a Druid, and he can only assume animal forms for a limited time. This skill enhances his constitution while in animal form, thereby increasing the amount of time he can remain transformed. 
This skill provides extra 5 turns and 15 maximum HP bonus for all animal forms. It also provides 1 extra bonus to melee THAC0 for Werewolf, 1 extra bonus to AC as well as melee damage for WereBear. Can be learned for 6 times, each choice will replace existing Werewolf and Werebear in spellbook with more powerfull spells, which must be stored to spell memorization before working. High-level skill.

Werebear (Transmutation)
Level: 3
Range: 0
Duration: 1 turn / level
Casting Time: 1
Area of Effect: Caster
Saving Throw: None
This spell empowers the Druid with the capacity to assume the form of a savage bear, granting him great strength and fortitude. The caser temporarily gains +6 to maximum HP per level (up to +90 to maximum HP at level 15). He also obtains +2 bonus to AC, +2 to melee damage, and +0.5 attack per round, which is a repeatable bonus to obtain on each 5 levels (up to +6 bonus to to AC and melee damage and +1.5 attacks per round at level 15). 

Maul
A Druid in Werebear form uses his mighty paws to rend brutal gashes in the flesh of his enemies. Using this ability, the fury of his assault increases with every opponent he kills. This skill lasts for 4 rounds, each successful melee attack in skill duration can stun an opponent if he fails his save vs. death, the attack  aslo adds a 'charge' which brings a shinning ball (lasts for 4 rounds) around the Druid. When each charge is obtained, the Druid gains +2 to melee damage (up to +10) and the skill duration is recounted at the beginning. Such recounting is stopped when a full state of 5 charges is reached. If another attack skill is casted while the shinning ball exists, the effects of stunning and improved melee damage can retain before the ball exhausts, but new charges will no further be obtained. 
 Below LV10: +2 to melee THAC0, stuns an enemy for 1 second, the enemy must save vs. death with -1 penalty;  LV10: +3 to melee THAC0, stuns an enemy for 2 seconds, the enemy must save vs. death with -2 penalty; LV15: +4 to melee THAC0, stuns an enemy for 3 seconds, the enemy must save vs. death with -3 penalty; LV20: +5 to melee THAC0, stuns an enemy for 4 seconds, the enemy must save vs. death with -4 penalty.

Feral Rage
When in wolf form, the Druid using this ability enters a frenzied rage, viciously tearing into foes and becoming heartier with each consecutive attack.  This skill lasts for 4 rounds, each successful melee attack in skill duration can add a 'charge' which brings a shinning ball (lasts for 4 rounds) around the Druid. When each charge is obtained, the Druid gains ability of leeching 4 HP on melee attacks and +1 to move speed, at the same time the skill duration is recounted at the beginning. Such recounting is stopped when a full state of 5 charges is reached. If another attack skill is casted while the shinning ball exists, the effects of leeching and improved move speed can retain before the ball exhausts, but new charges will no further be obtained. 
 Below LV10: +2 to melee THAC0, +1 to melee damage;  LV10: +3 to melee THAC0, +2 to melee damage; LV15: +4 to melee THAC0, +3 to melee damage; LV20: +5 to melee THAC0, +4 to melee damage.

Fire Claws
While in his animal form, a Druid can use his affinity with the natural elements in order to supplement his attacks with a blazing assault. Duration: 4 rounds. Can be casted at LV10.
 LV10: +3 to melee THAC0, +5d4 fire damage;  LV15: +4 to melee THAC0, +5d6 fire damage; LV15: +5 to melee THAC0, +5d8 fire damage; LV20: +6 to melee THAC0, +5d10 fire damage.

Rabies
When a Druid in wolf form utilizes this ability, he toxifies his own saliva and attacks his enemies with a vicious bite, spreading a contagious disease that wracks the flesh of his infected opponents. An infected enemy passes the disease to other enemies nearby, but never affects the caster's teammates. Duration: 4 rounds. Can be casted at LV10.
 LV10: +2 to melee THAC0, infect each victim for 6 seconds and does 3 poison damage per second;  LV15: +3 to melee THAC0, infect each victim for 8 seconds and does 4 poison damage per second; LV20: +4 to melee THAC0, infect each victim for 10 seconds and does 5 poison damage per second; LV25: +5 to melee THAC0, infect each victim for 12 seconds and does 6 poison damage per second.

Shock Wave
With a tremendous roar, the Druid shakes the earth, stunning any enemies in the surrounding area with the resultant tremor. This spell stuns enemies in a range of 30' cone with 120-deg. arc and causes crushing damage. Successfully saving vs. death will reduce the damage and stunning time to half. Can be casted at LV20.
 LV20: 2d4 damage, stun for 2 seconds; LV25: 2d6 damage, stun for 3 seconds; LV30: 2d8 damage, stun for 4 seconds; LV35: 2d10 damage, stun for 5 seconds; LV40: 2d12 damage, stun for 6 seconds.

Hunger
Nature gives life, but it can also snatch it back. When a Druid using this ability bites an opponent, he drains some of his victim's vital essence, replenishing his own. This skill lasts for 4 rounds, during which the Durid obtains a state of improved haste, but all his attacks only deal minimum damage. Each successful melee attack in skill duration aslo drains some life and restores a casted divine spell to memory.  Can be casted at LV15.
 LV15: +2 to melee THAC0, leeches 1d8 HP, restores a spell of LV1-3; LV20: +3 to melee THAC0, leeches 2d8 HP, restores a spell of LV1-5; LV25: +4 to melee THAC0, leeches 3d8 HP, restores a spell of LV1-6; LV30: +5 to melee THAC0, leeches 4d8 HP, restores a spell of LV1-7.

Fury
The use of this skill drives the Druid into a bloodthirsty frenzy, attacking many foes with a raging fervor. The Druid in Werewolf form obtains 5 attacks per round and improved melee attacks. Duration: 4 rounds. Can be casted at LV20.
 LV20: +4 to melee THAC0, +6 to melee damage; LV25: +5 to melee THAC0, +7 to melee damage; LV30: +6 to melee THAC0, +8 to melee damage; LV35: +7 to melee THAC0, +9 to melee damage; LV40: +8 to melee THAC0, +10 to melee damage.

*Maul, Feral Rage, Fire Claws, Rabies, Hunger, Shock Wave and Fury can only be casted in animal form. In which Fire Claws, Rabies, Hunger and Fury can not take effect together with each other, each of them will directly replace a pre-casted one. Only the effects of Maul and Feral Rage can persist and work with another skill as long as a shinning ball exists.
*When a Druid transformes, a button of Attack Skill is granted on his Special Ability, by pressing which the skills above (Maul, Feral Rage, Fire Claws...) can be chosen to cast. Such ability is obtained on level 3, 6, 9 and 12, more ability amounts requires learning of High-level skills.


Summoning

Raven (Conjuration)
Level: 1
Range: Visual sight of caster
Duration: 5 turns
Casting Time: 1
Area of Effect: Special
Saving Throw: None
Summon Ravens to peck out the eyes of your enemies. Ravens follow the summoner and attack nearby enemies (in 10') once per round, which causes 1d2 damage and blind enemies if they fail to save vs. breath. One raven totally attack 5 + 1 times / 4 casting levels, it'll disappear after total attack limit or summoning duration exhausts. A raven does not occupy the limited quantity of summoned units, but when there're already five summoned units, it can't be summoned.

Poison Creeper (Conjuration)
Level: 2
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
A subtle ally, these intelligent vines travel through the ground and use their cruel thorns to poison any opponents they contact. The vine attacks once per round, which causes a poison state of 6 seconds with 1 poison damage per second / 4 Druid levels. The vine attains half of the level of the caster's and has HD of d6 per level. Vines stay invisible under the ground and only become briefly visible on attacking. 
Vines can follow the Druid across different areas unless killed or party rest. Only one vine can be summoned at a time. Vines don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.
While on selection, vines switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Oak Sage (Conjuration)
Level: 2
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
The Druid uses this ability to call upon a helpful spirit of Nature to enhance his well-being, as well as the health of his companions. The spirit doesn't attack but can provide an aura that increases Maximum HP for 12 points / 2 Druid levels (up to 120). The spirit attains half of the level of the caster's and has HD of d4 per level. 
Spirits of Nature can follow the Druid across different areas unless killed or party rest. Only one spirit can be summoned at a time. Spirits of Nature don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.

Summon Spirit Wolf (Conjuration)
Level: 3
Range: Visual sight of caster
Duration: 1 turn / level
Casting Time: 2
Area of Effect: Special
Saving Throw: None
This gift of Nature allows the Druid to conjure forth one or more wolf allies who, with their mystical powers, provide the Druid a potent and ferocious colleague. A spirit wolf possesses strength, dexterity and constitution of 15, and gains +1 to dexterity and THAC0 at each 2 levels of the summoner. A spirit wolf is regarded to has a melee weapon of 1d6 base damage, which equals to a +1 enchanted weapon when the summoner is less than level 10, it gains +1 enchantment with every 10 levels of the Druid and become a maximum +3 enchanted when the the Druid reaches level 20. Spirit wolves attain half of the level of the caster's and have HD of d4 per level. 
While on selection, wolves switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Carrion Vine (Conjuration)
Level: 4
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
The sentient plant summoned by this spell draws your enemies into the ground, where it rapidly decomposes their bodies, giving their life energies to the Druid who summoned it. The vine attacks once per round, which drains 1d6 hp / 2 Druid levels, one half of the drained hp is provided to the Druid, another half is drawn by the vine itself. The vine attains half of the level of the caster's and has HD of d6 per level. Vines stay invisible under the ground and only become briefly visible on attacking. 
Vines can follow the Druid across different areas unless killed or party rest. Only one vine can be summoned at a time. Vines don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.
While on selection, vines switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Heart of Wolverine (Conjuration)
Level: 4
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This ability grants the Druid the knowledge needed to summon into being a spirit that increases his skill in battle, as well as that of his party. The spirit doesn't attack but can provide an aura that give bonus to THAC0 and damage for +1 / 2 Druid levels (up to +10). The spirit attains half of the level of the caster's and has HD of d8 per level. 
Spirits of Nature can follow the Druid across different areas unless killed or party rest. Only one spirit can be summoned at a time. Spirits of Nature don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.

Summon Dire Wolf (Conjuration)
Level: 5
Range: Visual sight of caster
Duration: 1 turn / level
Casting Time: 2
Area of Effect: Special
Saving Throw: None
This blessing from Nature imparts to the Druid the ability to summon several great wolves. Though the wolf is already fierce in combat, its savagery becomes greatly inflamed as it consumes the corpses of fallen foes. A dire wolf possesses strength, dexterity and constitution of 15, and gains +1 to constitution at each 2 levels of the summoner. A dire wolf is regarded to has a melee weapon of 1d8 base damage, which equals to a +2 enchanted weapon when the summoner is less than level 10, it gains +1 enchantment with every 10 levels of the Druid and become a maximum +4 enchanted when the the Druid reaches level 20. On battle the wolf has a chance of 15% to drain 1d8 HP and go berserk, which brings +6 to melee damage for 4 rounds. Dire wolves attain half of the level of the caster's and have HD of d6 per level. 
While on selection, wolves switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Solar Creeper (Conjuration)
Level: 6
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This skill conjures forth an intelligent plant that draws the enemy's body into the earth, where it drains their spiritual essences and bestows them upon the Druid who summoned it. The vine attacks once per round, which drains 1d6 hp / 2 Druid levels, one half of the drained hp is turned to magic energy to restore a casted spell for the Druid, another half is drawn by the vine itself. The vine attains half of the level of the caster's and has HD of d8 per level. Vines stay invisible under the ground and only become briefly visible on attacking. 
Vines can follow the Druid across different areas unless killed or party rest. Only one vine can be summoned at a time. Vines don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.
While on selection, vines switch to a defensive mode by press D, and return to normal mode by press N. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.

Spirit of Barbs (Conjuration)
Level: 6
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
The spirit invoked by this skill bestows upon the Druid and his company the mystical ability to reflect damage back at any opponents who injure them.  The spirit doesn't attack but can provide an aura that reflects piercing damage (1d4 / 2 Druid levels, up to 10d4) to melee attackers. The spirit attains half of the level of the caster's and has HD of d12 per level. 
Spirits of Nature can follow the Druid across different areas unless killed or party rest. Only one spirit can be summoned at a time. Spirits of Nature don't occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned.

Summon Grizzly (Conjuration)
Level: 7
Range: Visual sight of caster
Duration: Special
Casting Time: 3
Area of Effect: Special
Saving Throw: None
This boon grants the Druid the aid of a tremendous wild bear with huge claws and great fangs that fights ferociously alongside him with terrible strength and unmatched fury.  A grizzly bear possesses strength, dexterity and constitution of 15, and gains +1 to strength at each 2 levels of the summoner. A grizzly bear is regarded to has a melee weapon of 1d10 base damage with+4 enchanted, which becomes +5 enchanted when the the Druid reaches level 20. On battle the bear has a chance of 25% to stun enemies for 2-3 seconds (save vs. breath to avoid being stunned). Grizzly bear attains half of the level of the caster's and have HD of d12 per level.
A grizzly bear can follow the Druid across different areas unless killed or party rest. Only one bear can be summoned at a time. It doesn't occupy the limited quantity of summoned units, but when there're already five summoned units, it can't be summoned.
While on selection, the grizzly switches to a defensive mode by press D, and returns to normal mode by press N. In the defensive mode, it'll not attack enemies initiatively unless get closed and attacked.

*Druid's summonings are immune to fear and charm.


Other High-level skills

Transformed Feats
While in animal form, this skill adds one more Attack Skill for the Druid to cast in Special Ability. Can be learned for 6 times. 

Nature Agility
This skill provides +2 bonus to THAC0 and AC for Druid's wolves and bears. Can be learned for 8 times. 

Nature Vitality
This skill provides +2 hit dices and +1 bonus to all saves for Druid's wolves and bears. Can be learned for 8 times. 

Nature Might
This skill provides +2 to melee damage for Druid's wolves and bears. Can be learned for 8 times. 


----------VERSION HISTORY----------

V0.5 Adjusted the compatibility with other Diablo2 kits for no EE games.
  Fixed the problem that Shock Wave has a wrong area of effect after LV40.
  New mechanism for Transformed Feats, less burden for global script.

V0.4 Fixed the problem that the Druid can keep invisible on casting hostile spells.
  Fixed the problem that saving and loading games on the moment of summoned creatures' appearing may bring them some ability loss.
  Reduced the immunity for summoned creatures, they're no longer immune to chaos, imprisonment and petrification. (If a creature that only one can exist at the same time is imprisoned or petrified, the same creature can't be summoned again. Try resting and 
reverse spell in such a case.)
  Fixed the overly damage rate of Arctic Blast when casted on multiple targets.
  Fixed (?) the problem of increasing amount of Attack Skill in animal form.
  Fixed the problem that Vines can keep invisible on attacking.
  Fixed the overly rapid rate of HP regeneration of summoned creatures.
  Fixed the damage of Poison Creeper.
  Spirits run away when come near to a enemy.
  Growing of some skills is extended to LV40.
  Less stunned duration of Shock Wave.

V0.3 Hot keys of animals are set to D (Defence) and N (Normalize). 
  Fixed all kinds of strange problems of summoned creatures. 
  Fixed the problem that ravens attack once less time than described. And ravens' existence time grows up to 5 minutes.
  Fixed the problem that animals do not interact with the Druid after saving and loading games.
  Fixed the problem that high-level skills have noting to do with wolves and bears.
  Fixed the problem that animals sometimes don't attack an enemy but stay still. 
  Fixed the problem that damage of Molten Boulder, Twister, Tornado and Armageddon do not increase with caster's level, and the problem that enemies killed by above spells do not count as Druid's killings. 
  Twister and Shock Wave now show animation of stunning.
  AOE skills now ignore the protection of Mirror Image spell (EE only).
  Fixed the problem that the Rabies skill does not appear at LV10.
  Learning of the high-level skill Lycanthropy will replace existing Werewolf and Werebear in spellbook with more powerfull spells, which must be stored to spell memorization before working. 
  Attack Skills in animal form can be gained more frequently on lower level but no more after level 15. More ability amounts requires learning of High-level skills.

V0.2 Fixed the bug that animals don't follow the Druid across different areas after saving and loading.
  Fixed the bug that Druid be unable to cast Elemental Spells in human form after shape shifting. 
  Removed unexpect skills in human form after shape shifting.
  Fixed the problem that animals attack a target without judging whether it is hostile or not when it hurts the Druid. 
  Vines, spirits and grizzlies voluntarily take one step away when they overlaps each other or be very close to othe Druid.
  Cyclone Armor can be casted in animal form.
  Animation of leeching life and mana appears when attack with Hunger.
  A little decline of auras of Oak Sage and Heart of Wolverine.
  Fixed some mistakes of icons and text.
  Fixed transparency of some animations for their bad behaviour in no EE games.

V0.1 Finished the Druid kit.

