///////////////////////////////////////////////////////
//////Diablo2 Kit Pack - The Sorcerer Ver 0.4///////
///////////////////////////////////////////////////////

----------ATTENTIONS----------

    It is a Sorcerer kit for EE games only, not for original BG series.
    The Sorcerer is able to select wizard spells on level up, but immediately forgets them, with only Diablo2 spells left.

    Only one Sorcerer(D2) is suggested in a whole game, as multiple Sorcerers' skills and hirelings are in conflict.

    When selected, a hireling switches to a Defencive mode by press D, and returns to Normal mode by press N. In the defencive mode, he'll not attack enemies initiatively unless get closed and attacked.
    A hireling voluntarily takes one step away from the Sorcerer when they get too close, in order to avoid getting jammed when traveling across different areas. 
    You can speak with a hireling and give him some potion to drink.
    Hirelings do not occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned. If one hireling is imprisoned or petrified, a reverse magic is required to free him, or other hirelings can't be summoned.

----------KNOWN BUGS----------

    Frozen Orb always appears on top-left of the caster, its flying road will be blocked by the caster's body when casted towards down-right. You can manipulate the character to move and leave a road for it. 

    As the Infinity Engine has some problem on Level Modifiering, sometimes hirelings do not have correct levels, yet their attributes can grow up correctly.

----------DETAILED DESCRIPTION----------

Sorcerer
    The Sorcerer is an expert in mystical creation ex nihilo. Though somewhat lacking in the skills of hand-to-hand combat, he compensates for this weakness with fierce combative magic for both offense and defense. Solitary and reclusive, the Sorcerer acts based on motives and ethics inscrutable to most, and sometimes seems capricious and even spiteful. In reality, he understands the struggle between Order and Chaos all too clearly, as well as his role as a warrior in this battle. 

Advantages:
- New spells and high-level skills: Cold, Lightning and Fire Spells.
- No interval between spells.
- Constantly restoring spells to memory with the skill Warmth. 

Disadvantages:
- May not learn spells and high-level skills of original sorcerer.


Cold Spells

Ice Bolt (Evocation)
Level: 2
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 1
Area of Effect: 1 Creature
Saving Throw: Half
This spell shoots a bolt of ice that damages and slows your victim. It causes 1d4 points of damage per 2 levels of the caster (up to 10d4) and slow the enemy for 2 seconds per 4 levels of the caster (up to 12 seconds). Successfully saving vs. spell will reduce the cold damage and length to half.

Frozen Armor (Evocation)
Level: 1
Range: 0
Duration: 1 turn/level
Casting Time: 2
Area of Effect: Caster
Saving Throw: Special
This spell gives 2 bonus to AC at level 1, then gains 2 + 1 / 5 levels of the caster (up to +6) bonus to AC, and freezes any melee attacker that hits you for 1 + 1 second / 10 levels of the caster (up to 3 seconds).
Frozen Armor, Shiver Armor and Chilling Armor can not take effect together with each other. Each of them will directly replace a pre-casted one.

Frost Nova (Evocation)
Level: 4
Range: 0
Duration: Instantaneous
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Half
This spell creates an expanding ring of ice and frost that damages and slows enemies. It causes 1d4 points of damage per 2 levels of experience of the caster (up to 10d4) and slow the enemy for 2 + 2 seconds / 4 levels of the caster (up to 12 seconds). Successfully saving vs. spell will reduce the cold damage and length to half.

Ice Blast (Evocation)
Level: 3
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 2
Area of Effect: 1 Creature
Saving Throw: Half
This spell creates a bolt of ice that completely freezes a target. It causes 1d6 points of damage per 2 levels of experience of the caster (up to 10d6) and freezes the enemy for 4 + 1 second / 10 levels of the caster (up to 6 seconds). Successfully saving vs. spell will reduce the cold damage and length to half.

Shiver Armor (Evocation)
Level: 5
Range: 0
Duration: 1 round/level
Casting Time: 2
Area of Effect: Caster
Saving Throw: Special
This spell gives 3 bonus to AC at level 1, then gains +1 bonus to AC for every 5 levels (up to +7). Any melee attacker that attacks the caster will take damage and be slowed. The armor causes 1d4 points of damage per 2 levels of experience of the caster (up to 10d4) and slow enemies for 4 seconds. Successfully saving vs. spell will reduce the cold damage and length to half.
Frozen Armor, Shiver Armor and Chilling Armor can not take effect together with each other. Each of them will directly replace a pre-casted one.

Glacial Spike (Evocation)
Level: 6
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 3
Area of Effect: 10' radius
Saving Throw: Half
This spell launches a shard of ice that inflicts massive cold damage and explodes to freeze enemies in 10' radius. It causes 1d6 points of damage per 2 levels of experience of the caster (up to 10d6) and freezes enemies for 4 seconds. Successfully saving vs. spell will reduce the cold damage and length to half.

Blizzard (Evocation)
Level: 9
Range: Visual sight of caster
Duration: 2 Rounds
Casting Time: 9
Area of Effect: 20' radius
Saving Throw: Half
This spell summons an ice storm to rain cold death onto your enemies, which causes 1d10 points of cold damage per 2 levels of the caster (up to 10d10) and slow enemies for 4 seconds when hit. The ice storm totally make 6 hits in 2 rounds, yet enemies in the effective area have 50% chance to avoid each hit. Successfully saving vs. spell will also reduce the cold damage and length to half.

Chilling Armor (Evocation)
Level: 7
Range: 0
Duration: 1 round/level
Casting Time: 2
Area of Effect: Caster
Saving Throw: Special
This spell gives 3 bonus to AC at level 1, then gains +1 bonus to AC for every 5 levels (up to +7). The armor launches an ice bolt against each melee and ranged attacker, causes 1d4 points of damage per 2 levels of experience of the caster (up to 10d4) and slow enemies for 4 seconds. Successfully saving vs. spell will reduce the cold damage and length to half.
Frozen Armor, Shiver Armor and Chilling Armor can not take effect together with each other. Each of them will directly replace a pre-casted one.

Frozen Orb (Evocation)
Level: 8
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 8
Area of Effect: Special
Saving Throw: Half
This spell launches a pulsating orb that shreds an area with ice bolts. Each ice bolt causes 1d4 points of damage per 4 levels of experience of the caster (up to 5d4). Enemies hit by the spell is also slowed for 2 seconds per 4 levels of the caster (up to 12 seconds). Successfully saving vs. spell will reduce the cold damage and length to half.

Cold Mastery
Decreases enemies's cold resistance by 5%. Can be learned for 10 times. High-level skills.

Lightning Spells

Charged Bolt (Evocation)
Level: 1
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 1
Area of Effect: 90° sector with 10' radius
Saving Throw: Half
When this spell is cast, it causes a cone-shaped area of bolts of electricity, originating at the caster's hand and extending outward in a cone. Each bolt causes 1d4 points of damage per 2 levels of experience of the caster and up to 10d4. Enemies in effective area may be hit by 1-3 bolts, and chance of hitting by more than one bolt increses with level of the caster. Successfully saving vs. spell will reduce the electricity damage to half.

Telekinesis (Transmutation)
Level: 2
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 1
Area of Effect: 1 Creature
Saving Throw: Half
With this skill a Sorcerer can reach out with his mind and manipulate distant objects. This spell can be used to open a lock or a box, or to impact an enemy at a distance. It can stun an enemy for 2 seconds, and cause 1D4 electricity damage. Enemies that successfully save vs. spell will be stunned for only 1 second.

Static Field (Evocation)
Level: 3
Range: 0
Duration: Instantaneous
Casting Time: 2
Area of Effect: Special
Saving Throw: None
When this spell is cast, every enemy around you lose 25% of their current health. It affects a radius of 5' + 3' / 4 levels of the caster (up to 20' at lv20).

Lightning (Evocation)
Level: 4
Range: Visual sight of caster
Duration: Instantaneous 
Casting Time: 3
Area of Effect: Special
Saving Throw: Half
Upon casting this spell, the caster releases a powerful stroke of electrical energy that inflicts 1d20 points of damage per 2 levels of the spellcaster (maximum damage of 10d20) to each creature within its area of effect. A successful saving throw vs. spell reduces this damage to half. 

Nova (Evocation)
Level: 5
Range: 0
Duration: Instantaneous
Casting Time: 3
Area of Effect: 30' radius
Saving Throw: Half
This spell creates an expanding ring of electricity that does massive damage. It causes 1d10 points of damage per 2 levels of experience of the caster (up to 10d10). Successfully saving vs. spell will reduce the electricity damage to half.

Chain Lightning (Evocation)
Level: 6
Range: Visual range of caster
Duration: Instantaneous
Casting Time: 3
Area of Effect: Special 
Saving Throw: Half 
When the caster casts Chain Lightning, arcs of electrical energy burst from his fingertips. These brilliant arcs of lightning leap at enemies near the caster, burning them with electrical damage. The lightning causes 1d12 points of damage for every 2 levels of the caster (maximum damage of 10d12), then jumps to the next nearest enemy, losing a small amount of energy with each additional strike until it is expended. Each jump the bolt makes reduces the damage by 1d12. If the target of the lightning saves against spells only half damage is inflicted.

Teleport (Transmutation) 
Level: 7
Range: Visual range of caster
Duration: Instant 
Casting Time: 1
Area of Effect: The caster
Saving Throw: None 
This spell instantly transports the caster between two points. 

Thunder Storm (Evocation)
Level: 9
Range: 0
Duration: 1 round/level
Casting Time: 9
Area of Effect: 30' radius
Saving Throw: Half 
This spell summons a thunderstorm that periodically blasts a nearby enemy with a bolt of lightning. The caster can call down one bolt per round. Each bolt causes 1d4 points of electrical damage for each of the caster's experience levels (maximum damage of 20d4). Successfully saving vs. spell will reduce the electricity damage to half.

Energy Shield (Abjuration)
Level: 8
Range: 0
Duration: 8 hours
Casting Time: 2
Area of Effect: Caster
Saving Throw: None
This spell absorbs damage to memorized spells instead of hit points. All resistance of the caster will be set to 15% + 4%/level (up to 95%), yet lose one spell of highest level in memory with each successful strike from enemy.

Lightning Mastery
Increases the damage of lightning spells by 9%. Can be learned for 10 times. High-level skills.

Fire Spells

Fire Bolt (Evocation)
Level: 1
Range: Visual sight of caster
Duration: Instantaneous
Casting Time: 1
Area of Effect: 1 Creature
Saving Throw: Half
This spell creates a bolt of fire that damages your victim. It causes 1d6 points of damage per 2 levels of experience of the caster (up to 10d6). Successfully saving vs. spell will reduce the fire damage to half.

Warmth
Constantly restoring spells to memory. Gained at LV1, and can be automatically improved on level 6, 10, 14 and 18.
  LV1: Restore a spell up to LV2 in every 10 rounds.
  LV6: Restore a spell up to LV2 in every 9 rounds, a spell up to LV4 in every 10 rounds.
  LV10: Restore a spell up to LV2 in every 8 rounds, a spell up to LV4 in every 9 rounds, a spell up to LV6 in every 10 rounds.
  LV14: Restore a spell up to LV2 in every 7 rounds, a spell up to LV4 in every 8 rounds, a spell up to LV6 in every 9 rounds, a spell up to LV8 in every 10 rounds.
  LV18: Restore a spell up to LV2 in every 6 rounds, a spell up to LV4 in every 7 rounds, a spell up to LV6 in every 8 rounds, a spell up to LV8 in every 9 rounds, a spell up to LV9 in every 10 rounds.
Extra improvement of Warmth is also available in high-level skills, which reduce time cost of all level by 1 round on each selection.
  1st selection: Restore a spell up to LV2 in every 5 rounds, a spell up to LV4 in every 6 rounds, a spell up to LV6 in every 7 rounds, a spell up to LV8 in every 8 rounds, a spell up to LV9 in every 9 rounds.
  2nd selection: Restore a spell up to LV2 in every 4 rounds, a spell up to LV4 in every 5 rounds, a spell up to LV6 in every 6 rounds, a spell up to LV8 in every 7 rounds, a spell up to LV9 in every 8 rounds.
  3rd selection: Restore a spell up to LV2 in every 3 rounds, a spell up to LV4 in every 4 rounds, a spell up to LV6 in every 5 rounds, a spell up to LV8 in every 6 rounds, a spell up to LV9 in every 7 rounds.
  4th selection: Restore a spell up to LV2 in every 2 rounds, a spell up to LV4 in every 3 rounds, a spell up to LV6 in every 4 rounds, a spell up to LV8 in every 5 rounds, a spell up to LV9 in every 6 rounds.
  5th selection: Restore a spell up to LV2 in every round, a spell up to LV4 in every 2 rounds, a spell up to LV6 in every 3 rounds, a spell up to LV8 in every 4 rounds, a spell up to LV9 in every 5 rounds.

Inferno (Evocation)
Level: 2
Range: Visual sight of caster
Duration: Special
Casting Time: 1
Area of Effect: Special
Saving Throw: Half
This spell creates a spout of flame that keep burning your enemies . It causes 1d6 points of damage per second per 2 levels of experience of the caster (up to 10d4) on each hit. Successfully saving vs. spell will reduce the fire damage to half.

Blaze (Evocation)
Level: 4
Range: 0
Duration: 3 + 1 second/level
Casting Time: 2
Area of Effect: Special
Saving Throw: Half
Leave a wall of fire in your footsteps. The fire wall exists for 6 seconds and causes 1d6 points of damage per second per 2 levels of experience of the caster (up to 10d8) per round. Successfully saving vs. spell will reduce the fire damage to half.

Fireball (Evocation)
Level: 3
Range: Visual range of caster 
Duration: Instantaneous 
Casting Time: 3
Area of Effect: 10' radius 
Saving Throw: Half
This spell creates a ball of fire that explodes on impact, which delivers damage proportional to the level of the caster who cast it - 1d8 points of damage for each level of experience of the spellcaster (up to a maximum of 10d8). Those who roll successful saving throws manage to dodge, fall flat, or roll aside, each receiving half.

Fire Wall (Evocation)
Level: 7
Range: Visual range of caster 
Duration: 1 round
Casting Time: 7
Area of Effect: Special
Saving Throw: Half
This spell creates a wall of fire. Any enemy unwitting enough to attempt to cross the wall will feel the full force of these flames as they advance to their ruin. The fire wall causes 1d10 points of damage per second per 2 levels of experience of the caster (up to 10d10). Successfully saving vs. spell will reduce the fire damage to half.

Enchant (Enchantment)
Level: 5
Range: Visual range of caster 
Duration: 1 turn/level
Casting Time: 5
Area of Effect: One Creature
Saving Throw: None
This spell temporarily adds Fire damage to a weapon. User of the enchanted weapon will get +1 attack bouns and 1d3 fire damage per 2 levels of the caster (up to +10 attack bouns and +10d3 fire damage).
Only half of the fire damage is added to a ranged weapon.

Meteor (Evocation)
Level: 8
Range: Visual range of caster 
Duration: Special
Casting Time: 8
Area of Effect: 20' radius
Saving Throw: Half
This spell draws down a meteor from the heavens to smash your enemies. The comet does 1d12 fire damage for each 2 levels of experience of the spellcaster (up to a maximum of 10d12) and continues burning on ground for 4 seconds, hurts enemies with 2d6 + 1 fire damage per 2 levels (up to a maximum of 2d6 + 10) per second. Successfully saving vs. spell will reduce the fire damage to half.

Fire Mastery
Increases the damage done by your fire spells by 7%. Can be learned for 10 times. High-level skills.

Hydra (Conjuration)
Level: 9
Range: Visual range of caster 
Duration: 2 rounds
Casting Time: 9
Area of Effect: Special
Saving Throw: Special
This spell creates a multi-headed beast that attacks your enemies with bolts of fire. The Hydra has only half the level of the caster and up to LV10. Each bolt causes 1d4 points of damage per 2 levels of experience of the Hydra (up to 5d4). Successfully saving vs. spell will reduce the fire damage to half.

*All offensive spells have no save penalty when cast by the Sorcerer under level 10, yet for every 10 levels a -1 penalty to saves will be imposed. So when the Sorcerer arrives lv50, his opponents should make save vs. spell with -5 penalty.

Other Spells

Summon Hirelings (Conjuration)
Level: 6
Range: 0 
Duration: Special
Casting Time: 6
Area of Effect: Caster
Saving Throw: None
This spell open a portal that traverse a large distance, from which a hireling of specific class can bse chosen and summoned from Elly the archer, Azrael the paladin, Jarulf the mage and Khan the barbarian. A cost of 100 gold is required for each level of the hireling. A hireling has an same level with the caster, and gains level up with the caster. All hirelings, except the mage, have a +3 enchanted weapons when they reach level 10, and gain +1 enchantment with every 5 levels, maximum +5 enchanted will be reached at level 20. Hirelings also have more chance to cast battle skills on level growth. The archer casts Inner Sight and chooses one from Fire Arrow or Ice Arrow, the paladin casts Jab and Holy Freeze Aura, the mage casts Frozen Armor and chooses spells of one element from fire, cold and lightning (fire: Fireball + Inferno, cold: Ice Blast + Glacial Spike, lightning: Charged Bolt + Lightning, in which Fireball, Ice Blast and Charged Bolt are regarded as LV3 spells,  Inferno, Glacial Spike and Lightning are regarded as LV6 spells, while all spells are casted only as half level of the mage. The mage do not actively cast spells at enemies with some spell protections. Try manually casting a Marking spell on one enemy, the mage will only focus on him within four rounds), the barbarian casts Bash and Stun.
A hireling is immune to charm, control, and morale break. He will stand along with the summoner unless killed or dismissed. Only one hireling can be summoned at a time. He will not occupy the limited quantity of summoned units.
When selected, a hireling switches to a Defencive mode by press D, and returns to Normal mode by press N. In the defencive mode, he'll not attack enemies initiatively unless get closed and attacked.

----------VERSION HISTORY----------

V0.4 Fixed the damage of Charged Bolt.
  Fixed the problem that Hydra may not appear.
  Fixed the burning area of Meteor on high level.
  Improved the damage Dice of Blaze from d6 to d8.
  Lightning bolt no longer bounces on wall or damage allies.
  Fixed AC bonus of Frozen Armor, Shiver Armor and Chilling Armor.
  Damage increasing of Lightning Mastery changed to 9% per skill level.
  Fixed the problem that the Sorcerer can keep invisible on casting hostile spells.
  Reduced the immunity for Hirelings, they only keep immune to charm, control and morale break.
  Fixed the problem that saving and loading games on the moment of Hirelings' appearing may bring them some ability loss.
  You can now speak with Hirelings to give them some potion to drink.

V0.3  Fixed the problem that hirelings of low level do not interact with the Sorcerer after saving and loading.
  In order to avoid getting jammed when traveling across different areas, a hireling voluntarily takes one step away from the Sorcerer when they get too close. 
  Adjusted the restoring speed and spell levels of Warmth. Fixed the BUG that Warmth didn't work completely on certain level. 
  Fixed the BUG that some Sorcerer spells ignore magic resistance.
  Fixed the problem that Cold Mastery causes lags and may not take effect in some areas.
  Solved the problem that high-level skills do not keep current levels when character is exported and imported or enter a TOB game from SOA.

V0.2 Hot keys of hirelings are set to D (Defence) and N (Normalize). 
  Fixed the bug that Inferno gives too many attacks, its D4 damage dice grows to D6 as a compensation.
  Meteor can be casted on any area instead of a creature. Missing of meteor animation in some game versions is also fixed.
  Cold Mastery now decreases enemies's cold resistance, but it may not take effect on some areas that don't require gathering your party before venturing forth.
  Hirelings no longer disappear on rest. They even gain level up with level growth of the Sorcerer now.
  Fixed the bug that hirelings don't teleport with the Sorcerer after saving and loading.
  Hirelings use battle skills more frequently with level growth. 
  Spell Schools of Enchant and Energy Shield became Enchantment and Abjuration respectively.
  AOE skills now ignore the protection of Mirror Image spell.
  Shooting range of Frozen Orb decreases to 15'.
  Remade all spell icons.
  Some spells now have corresponding animations.
  Increased affect range of Lightning.
  Can interact with 'Jamella's Diablo2 Item Store' V2.0 or later, allowing hirelings to choose one runeword weapon.

V0.1 Finished the Sorcerer kit.
