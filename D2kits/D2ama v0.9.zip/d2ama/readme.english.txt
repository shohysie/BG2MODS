/////////////////////////////////////////////////////
/////Diablo2 Kit Pack - The Amazon Ver 0.9/////////
/////////////////////////////////////////////////////

----------ATTENTIONS----------

  It is a Ranger kit for BG2, BGT and EE series.

  Only one Amazon is suggested in your team, as high-level skills (e.g. Valkyrie) of multiple Amazons will be in conflict.

  Amazon gains one "Skill Point" each level until 3,000,000 exp, player can get one skill that you like to learn by consuming each "Skill Point".
  *If you do press a "Skill Point" at skill table but then close the arisen skills table without making a choice, the "Skill Point" does nothing by get wasted!
  Some skills do not appear at low level. Maybe you'd store the "Skill Points" up to high level to purchase powerful skills.

  Decoys and Valkyries do not occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned. When the Valkyrie is imprisoned or petrified, a reverse magic is required to free her, or else she can't be summoned again.
  While on selection, Valkyrie switches to a Defensive mode by press D, and returns to Normal mode by press N. In the defensive mode, she'll not attack enemies initiatively unless get closed and attacked.
  Valkyrie voluntarily takes one step away from the Amazon when they get too close, in order to avoid getting jammed when traveling across different areas.
  Skill that increases attack rate, e.g. Jab, Fend and Pierce, begins to take effect only when melee (Jab, Fend) or ranged (Pierce) attacks hit.

  Dodge, Avoid, and Evade give a huge glowing white wiffle ball animation, so there's an extra component to turns off the animation. (This component comes from the Ease of Use Mod Pack, which also turns off the animation for Spell Trap spell and Cloak of Mirroring.)

----------KNOWN BUGS----------

  Do Not choose the high-level skill Pierce if your Amazon's ranged attack rate has already reached 5 times per round, or the Pierce skill will cause a decrease of attack rate to 4.5 per round.
  Amazon's combat skills may meet problems in case that MOD items which have immunity from "Removal: Remove Secondary Type" are equipped. This bug does not exist in EE games.

----------DETAILED DESCRIPTION----------

Amazon
This powerful woman warrior belongs to nomadic bands who roam the plains near the South Sea. The wandering of these groups often brings them into conflict with other peoples, so the Amazon is accustomed to fighting to defend her own. This lifestyle has made her fiercely independent and able to weather severe hardship and travel. While her skill with the bow rivals that of the Rogues, the Amazon is also adept in the use of spears and other throwing weapons, as well as in hand to hand combat. The Amazon is much sought after as a mercenary, in which type of service she will be loyal as long as her own ends are also served. 

Advantages:
- Has three skill trees: Javelin and Spear Skills, Passive and Magic Skills, Bow and Crossbow Skills.
- Can be grand master on spear, bow and crossbow.
- Get bonus of +1 to dexterity on character creation.

Disadvantages:
- Only be female.
- May not wear full plate or plate mail armors.
- May not learn Divine Spells and high-level skills of original Rangers.
- May not Charm Animal and be Stealthy.
- Only can be proficient on all weapons except spear, bow and crossbow.
- Unable to dual class.


Javelin and Spear Skills

Jab
Hunting in the dense rain forests of the Amazon Islands is fraught with many obstacles. Confining overgrowth and fierce indigenous animals conspire to make combat difficult, if not impossible. Early in training, Amazon spear-women must learn to overcome these conditions. By honing their hunting techniques to the point where they are able to deliver many powerful spear thrusts in rapid succession, they learn to finish off one opponent before turning to slay another. The Jab is the most basic of the skills designed to accomplish this tactic. 
This skill provides multiple attacks within the time span of a normal attack. 3 attacks per round in 4 rounds. Can be learned at LV1.
  LV1: +1 bonus to melee attack, -2 to damage; LV5: +2 bonus to melee attack; LV10: +3 bonus to melee attack, +2 to damage; LV15: +4 bonus to melee attack, +4 to damage.

Power Strike
Zerae is the bride of Hefaetrus, and her dominion is vengeance and storms. If an Amazon warrior is on a mission to right a great wrong and has proven herself worthy, the goddess will empower her with the ability to add the electrical power of the mighty hurricanes of the Southern Seas to her stabbing spear attacks. 
This skill adds lightning damage to melee attacks. Successfully saving vs. breath will reduce the lightning damage to half. Skill duration: 4 rounds. Can be learned at LV5.
  LV5: +2 bonus to melee attack, +1d8 lightning damage; LV10: +3 bonus to melee attack, +1d12 lightning damage; LV10: +4 bonus to melee attack, +1d16 lightning damage; LV10: +5 bonus to melee attack, +1d20 lightning damage.

Poison Javelin
Amazon healers have long since ascertained the potent toxicity of their native flora. Any Amazon warrior devoted to this study is able to recognize particularly lethal strains of plant life, even while traveling in foreign lands. This knowledge allows her to create weapons from particularly virulent woods. 
This skill launches a javelin that causes poison to enemies on the whole traverse route, targets must save vs. death or be poisoned for 1 damage per second. A next skill can be casted immediately after Poison Javelin lauches. Can be learned at LV5.
  LV5: 1d8+2 piercing damage, target must save vs. death with -1 penalty or suffer poison for 2 rounds; LV10: 1d8+4 piercing damage, target must save vs. death with -2 penalty or suffer poison for 3 rounds; LV15: 1d8+6 piercing damage, target must save vs. death with -3 penalty or suffer poison for 4 rounds; LV20: 1d8+8 piercing damage, target must save vs. death with -4 penalty or suffer poison for 5 rounds.

Impale
Although deftness and superior hand-eye coordination are the hallmarks of the Amazon warrior, they are also well known for the ferocity of their attacks. An experienced warrior is able to focus her fury and deliver blows so powerful that they have been known to shatter their weapon in the process. 
This skill causes powerful but slow attacks with melee weapon, Amazon losts about 30% of attacks of each round. Skill duration: 4 rounds. Can be learned at LV10.
  LV10: +4 bonus to melee attack, +6 to damage; LV15: +6 bonus to melee attack, +8 to damage; LV20: +8 bonus to melee attack, +10 to damage; LV25: +10 bonus to melee attack, +12 to damage.

Lightning Bolt
If an Amazon warrior has proven herself worthy, the goddess Zerae can empower her with the ability to strike down enemies by hurling javelins charged with power as if she had snatched lighting from the heavens. 
This skill launches a trail of lightning and does lightning damage to enemies on the whole traverse route. Successfully saving vs. breath will reduce the lightning damage to half. A next skill can be casted immediately after Lightning Bolt lauches. Can be learned at LV10.
  LV10: 1d8+2 piercing damage, plus 4d8 lightning damage; LV15: 1d8+4 piercing damage, plus 4d10 lightning damage; LV20: 1d8+6 piercing damage, plus 4d12 lightning damage; LV25: 1d8+8 piercing damage, plus 4d14 lightning damage.

Charged Strike
An Amazon devoted to the path of Zerae will be able to harness the forces of vengeance and storms. During Rites of Vengeance, Zerae will confer to the Amazon attacks that unleash a wild burst of electrical energy, striking down nearby enemies. A grizzled veteran of the Time of Troubles once said: Spear-women walking the 'Path of Zerae' are best given wide berth, for they can be as violent and indiscriminant as the storms on the Twin Seas. 
This skill enhances your melee weapons with lightning attacks that releases charged bolts. Successfully saving vs. breath will reduce the chance of hit by more bolts. Skill duration: 4 rounds. Can be learned at LV10.
  LV10: A nearby enemy may be hit by 4 charged bolts, each bolt does 1d3 lightning damage; LV15: A nearby enemy may be hit by 5 charged bolts, each bolt does 1d4 lightning damage; LV20: A nearby enemy may be hit by 6 charged bolts, each bolt does 1d5 lightning damage; LV25: A nearby enemy may be hit by 7 charged bolts, each bolt does 1d6 lightning damage.

Plague Javelin
Practiced and cunning warriors are able to incorporate poisonous vegetation into the organs of wildlife, creating highly infectious and deadly bladders that the Amazons affix to their javelins. These javelins strike a target and explode into noxious and putrescent clouds. Entire armies of creatures and of men have been slaughtered by the ingenious use of these biological agents. The choking cloud created by a plague javelin will incapacitate even the strongest foes. 
This skill launches a javelin that causes a cloud of expanding poison of 15' radius and 4 rounds' duration. Enemies in cloud may save vs. death to reduce posion damage by half. A next skill can be casted immediately after Plague Javelin lauches. Can be learned at LV15.
  LV15: 2d8+2 piercing damage, poison damage 5d8 per round, enemies must save with -1 penalty; LV20: 2d8+4 piercing damage, poison damage 6d8 per round, enemies must save with -2 penalty; LV25: 2d8+6 piercing damage, poison damage 7d8 per round, enemies must save with -3 penalty; LV30: 2d8+8 piercing damage, poison damage 8d8 per round, enemies must save with -4 penalty.

Fend
Once an Amazon warrior has attained mastery over the spear, she can engage and destroy multiple enemies in close quarter battle. Many of those enemies will be lucky to be alive after the vicious onslaughts of these attacks have ended. Grand Mistress Celestia was able to demonstrate this ability to the Initiates of Athulua by striking down a dozen experienced warriors in the space of an arrow's flight. 
With this skill an Amazon can rapidly strike close targets, her number of attacks per round is set to 10 for 1 round. High-level skill.
  LV1: +1 bonus to melee attack and damage; LV25: +2 bonus to melee attack and damage; LV30: +3 bonus to melee attack and damage; LV35: +4 bonus to melee attack and damage; LV40: +5 bonus to melee attack and damage.

Lightning Strike
Through focus and intense devotion to Zerae, an experienced warrior can harness Zerae's gift of lighting to great effect. Such a warrior is able to call upon the Goddess' might to destroy her enemies, unleashing a bolt of lighting that arcs from foe to foe. 
This skill releases chain lightning from target on melee attacks. Successfully saving vs. breath will reduce the lightning damage to half. Skill duration: 4 rounds. Can be learned at LV15.
  LV15: chain lightning with 2d8 damage per hit; LV20: chain lightning with 2d12 damage per hit; LV25: chain lightning with 2d16 damage per hit; LV30: chain lightning with 2d20 damage per hit.

Lightning Fury
Possibly the most devastating, and certainly the most spectacular, of all the techniques learned by an Amazon warrior is Lightning Fury. The High Priestess of Zerae will teach select Amazons the secret of focusing the power of the goddess, consecrating a javelin to become the ultimate weapon of vengeance. The energy contained within the javelin is so powerful that its electrical energy explodes from its stricken target, releasing bolts of lightning that strike down hapless foes nearby. Swift and powerful is the justice administered by an eminent Amazon. 
This skill creates a powerful lightning bolt that releases multiple lightning bolts from target. Successfully saving vs. breath will reduce the lightning damage to half. A next skill can be casted immediately after Lightning Fury lauches. High-level skill.
  LV1: 2d8+2 piercing damage to target, and 2d12 lightning damage per bolt; LV25: 2d8+4 piercing damage to target, and 2d14 lightning damage per bolt; LV30: 2d8+6 piercing damage to target, and 2d16 lightning damage per bolt; LV35: 2d8+8 piercing damage to target, and 2d18 lightning damage per bolt; LV40: 2d8+10 piercing damage to target, and 2d20 lightning damage per bolt.


Passive and Magic Skills

Inner Sight
The lush canopy of trees covering the Amazon homeland allows little sunlight to reach the ground. To better adapt to their environment, the Amazons have developed a technique whereby they can attune themselves to the life forces in the surrounding area and transfer these energies into a source of luminescence. This enables the Amazon and her companions to see her enemies in shadow and darkness. 
This skill illuminates monsters and decreases their ability to defend themselves. This skill has a larger effective area than insight. Can be learned in LV1.
  LV1: -1 to enemy AC for 4 rounds; LV5: -2 to enemy AC for 6 rounds; LV10: -3 to enemy AC for 8 rounds; LV15: -4 to enemy AC for 10 rounds.

Critical Strike
Among the arsenal of techniques employed by the Amazon warrior is her ability to study opponents carefully and detect any weaknesses. She can then use these deficiencies in her adversary to strike at precisely those areas that will cause the greatest injuries. 
This skill permanently grants a chance to do double physical damage with your attacks. Passive skill, learned at LV1, LV5, LV10 and LV15.
  LV1: Set critical strike chance to 10%; LV5: Set critical strike chance to 15%; LV10: Set critical strike chance to 20%; LV15: Set critical strike chance to 25%.

Dodge
To anyone familiar with their natural agility, it should came as no surprise that the training regimen of an Amazon warrior includes exercises specifically designed to avoid potentially devastating blows in combat. 
This skill grants a chance to move out of the way of a melee attack. Permanently +2 bonus to AC against melee weapons and +8% chance to stay out of all physical attacks. Passive skill, learned at LV5, LV10, LV15 and LV20.

Slow Missiles
Through strict martial discipline and focus, an Amazon warrior can attune herself to her environment and the dangers around her, allowing her to react to these hazards with superhuman agility. One aspect of this ability is her knack for avoiding missile fire. Just as the Amazon must master the bow and javelin, she must also learn to defend herself from these same weapons. When an Amazon uses this ability, incoming projectiles appear to move slower than normal, enabling her to avoid them. 
This skill slows down all speed of ranged attack and spell casting of enemies insight. Skill duration: 4 rounds. Can be learned at LV5.

Avoid
This ability hones the natural defensive ability of an Amazon. If she stands still, she can predict incoming missile attacks and elude them before they reach her. Most Amazon people can do this if all of their thoughts to the task, but only a warrior trained in this skill can do this even whilst caught unaware. 
This skill grants a chance to move out of the way of a missile attack. Permanently +2 bonus to AC against melee weapons and +9% chance to stay out of all spells of offensive damage. Passive skill, learned at LV10, LV15, LV20 and LV25.

Penetrate
The warriors of the Amazon Islands are legendary for their ability to strike their mark. Warriors with this skill are more likely to hit targets. 
This skill provides additional chance to hit. Permanently +2 bonus to all attacks of Amamzon. Passive skill, learned at LV15, LV20, LV25 and LV30.

Decoy
Amazons derive another benefit while learning to fight in the rainforests of their homeland. They learn, through misdirection and deception, to fool attacking forces into thinking there is another Amazon nearby. This subterfuge causes enemies to waste time and energy hunting down false prey while the Amazon moves in for the kill. 
This skill creates a duplicate image to distract enemies until destroyed or time exhausts. The decoy's health point increases with level of the summoner, and gains bonuses equal to the summoner in Dodge, Avoid, and Evade. Can be learned at LV15.
  LV15: a 15HD decoy for 4 rounds; LV20: a 20HD decoy for 6 rounds; LV25: a 25HD decoy for 8 rounds; LV30: a 30HD decoy for 10 rounds.

Evade
A warrior skilled in Dodge and Avoid may eventually learn this additional ability. Once an Amazon has sharpened her defensive concentration to this level, she will eventually be able to moves out of the way of harmful area attacks or avoid the wrath of an enraged wizard! 
This skill keeps the Amazon away from the effects of harmful magics. Passive skill, high-level skill.
  Permanently grants 10% chance at each learning to stay out of all spells of magic attack, battle ground and disabling.

Valkyrie
When a warrior has proven her devotion to Athulua through her brave deeds and exceptional skill in battle, the Goddess shows her favor by granting a spiritual emissary to aid the Amazon. These emissaries of Athulua are called Valkyrie, and they are the spirits of the greatest heroes from the Amazon people. The power to summon a Valkyrie is the greatest honor that an Amazon warrior can receive. It is believed this gift is a sign that your place beside the Goddess is assured when you pass from this world-perhaps even as a Valkyrie. 
This skill summons a powerful Valkyrie warrior to fight by your side. High-level skill.
  Valkyrie is a fighter who has the same (or slightly less) level as her summoner. Her ability and equipments improve with her level (+3 equipments at level 20 and up to +5 at level 40), she also gains bonuses in Critical Strike, Dodge, Avoid, and Evade at an equal degree with the summoner. The Valkyrie can follow the summoner across different areas and attack any enemy. She will remain under the caster's control until destroyed in combat or when party rests. The Valkyrie doesn't occupy the limited quantity of summoned units.
  While on selection, Valkyrie switches to a Defensive mode by press D, and returns to Normal mode by press N. In the defensive mode, she'll not attack enemies initiatively unless get closed and attacked.
  Talk with the Valkyrie and you can send her back.

Pierce
After long hours of training, an Amazon warrior's bow arm can develop tremendous amounts of strength. With this strength, and some additional training, the Amazon is able to maximize the power of her bow, enabling her to penetrate multiple targets with a single arrow. 
This skill permanently grants one more chance to attack per round when attack with ranged weapons. Passive skill, high-level skill.


Bow and Crossbow Skills

Magic Arrow
Far in the ancient past, Amazons found their glorious arboreal city of Tran Athulua under siege by the pirates of the Twin Seas. These cut-throats were determined to turn the Amazon Islands into their base of operations. The conflict lasted many months as the pirates laid in for a long siege. During the battle, supplies ran short, and the Amazon archers found themselves without ammunition. Realizing that their defense rested solely upon the ability of the archers to keep the corsairs at bay, the priests of the city prayed to Athulua to aid them. In answer, Athula infused the minds of the Amazons with the power to harness their natural spiritual energies. One by one the archers melded their determination and will into shards of physical force that they then unleashed from their bows by the thousands, firmly routing the corsairs back to sea. 
This skill enchants arrows with magic, converts some physical damage to a more powerful magic damage. Skill duration: 4 rounds. Can be learned at LV1.
  LV1: +1 bonus to ranged attack, -1 to physical damage but +2 to magic damage; LV5: +2 bonus to ranged attack, -2 to physical damage but +4 to magic damage; LV10: +3 bonus to ranged attack, -3 to physical damage but +6 to magic damage; LV15: +4 bonus to ranged attack, -4 to physical damage but +8 to magic damage.

Fire Arrow
Hefaetrus is the Amazonian god of fire and rebirth who lives deep within the great volcano, Mount Arnazeus, on the island of Philios. Although primarily the patron deity of farmers, from time to time he bestows his favors upon the warriors of the Islands, so they may keep safe his congregation. Through proper prayer and the sacrifice of many fierce enemies, an especially brave Amazon can attain the power to imbue her shots with the destructive power of fire, allowing her to rake blazing missiles from her bow. 
This skill enchants arrows with fire, converts some physical damage to a more powerful fire damage. Skill duration: 4 rounds. Can be learned at LV1.
  LV1: +1 bonus to ranged attack, -1 to physical damage but +1d4 to fire damage; LV5: +2 bonus to ranged attack, -2 to physical damage but +2d4 to fire damage; LV10: +3 bonus to ranged attack, -3 to physical damage but +3d4 to fire damage; LV15: +4 bonus to ranged attack, -4 to physical damage but +4d4 to fire damage.

Cold Arrow
Although winter never seems to find its way to the ever-balmy Amazon Islands, cold climates are not unheard of. The summit of Mount Karcheus on the island of Philios is covered with snow all year long. Deep within an icy cave secluded amongst its towering peaks, is the Great Hall of Mirrors where mighty Karcheus the Watcher sits upon his throne. Ever vigilant, Karcheus keeps watch over the people of the Amazons. Warriors who have trained within his temple are able to instill their shots with the power of a freezing wind. 
This skill enchants arrows with ice, converts some physical damage to a more powerful cold damage. Target must save vs. death with or be slowed for a short while. Skill duration: 4 rounds. Can be learned at LV5.
  LV5: +1 bonus to ranged attack, -1 to physical damage but +1d3 to cold damage, target must save with -1 penalty or be slowed for 3 seconds; LV10: +2 bonus to ranged attack, -2 to physical damage but +2d3 to cold damage, target must save with -2 penalty or be slowed for 4 seconds; LV15: +3 bonus to ranged attack, -3 to physical damage but +3d3 to cold damage, target must save with -3 penalty or be slowed for 5 seconds; LV20: +4 bonus to ranged attack, -4 to physical damage but +4d3 to cold damage, target must save with -4 penalty or be slowed for 6 seconds.

Multiple Shot
Legend has it that the fabled Amazon archer, Palashia, bragged in her youth that she could best the combined skills of all her greatest rivals. Taking umbrage, her rivals gathered to challenge her outrageous boast, arranging a contest to decide the question. To preserve her honor, Palashia was to strike the targets of all her rivals before they could land a single arrow. When dawn arose on the day of the contest, Palashia stood ready with her bow. At the signal, her rivals nocked their arrows and loosed a volley towards their targets. Palashia gathered her energies, and let fly with her own, single arrow. To the amazement of onlookers, her arrow split into many, cleaving the arrows of her rivals, and moving on to strike every target directly in their centers. This mysterious technique quickly became a martial secret that only the finest archers are able to master. 
This skill launches arrows that splited into several to attack enemies in a cone-shaped area of 120 degrees in angle. May hit enemies that out of sight range. A next skill can be casted immediately after Multiple Shot lauches. Can be learned at LV5.
  LV5: 1d6+2 damage per arrow, 100% chance to shoot one arrow at each of the enemies in effctive area，and a 50% chance to shoot one more arrow at each of the enemies; LV10: 1d6+3 damage per arrow, 100% chance to shoot two arrows at each of the enemies in effctive area; LV15: 1d6+4 damage per arrow, 100% chance to shoot two arrows at each of the enemies in effctive area，and a 50% chance to shoot one more arrow at each of the enemies; LV20: 1d6+5 damage per arrow, shoot three arrows at all enemies in effctive area.

Exploding Arrow
Another gift of Hefaetrus, an Amazon warrior practiced in this skill can imbue the arrows that she fires with the ability to explode upon impact. The resulting detonation not only allows her to damage her intended target, but also anything caught within the explosive blast. The sight of a full battalion of Amazon archers firing a volley of such arrows is eerily beautiful. Many warriors, having witnessed good friends consumed by the flames of these arrows, vow never to fight against Amazon warriors ever again. 
This skill adds fire damage to normal arrows and explodes on impact. Successfully saving vs. breath will reduce the fire damage to half. Skill duration: 3 rounds. Can be learned at LV10.
  LV10:  +1 bonus to ranged attack, the explosion grants 3d6 damage; LV15: +2 bonus to ranged attack, the explosion grants 4d6 damage; LV20: +3 bonus to ranged attack, the explosion grants 4d6 damage; LV25: +4 bonus to ranged attack, the explosion grants 6d6 damage.

Ice Arrow
The second of the prizes Karcheus bestows to a true warrior, this skill enables the Amazon to instill her arrows with the glacial force of a fierce blizzard. Enemies struck by this power not only feel the icy sting of the enchanted shaft, but also the force of a chilling arctic wind that, mysteriously, they alone can feel. 
With this skill the Amazon can fire arrows with additional cold damage and can momentarily freeze the target unless it saves vs. breath. Skill duration: 3 rounds. Can be learned at LV15.
  LV15: +1 bonus to ranged attack, +3d4 cold damage, target must save with -1 penalty or be freezed for 1 second; LV20: +2 bonus to ranged attack, +4d4 cold damage, target must save with -2 penalty or be freezed for 2 seconds; LV25: +3 bonus to ranged attack, +5d4 cold damage, target must save with -3 penalty or be freezed for 3 seconds; LV30: +4 bonus to ranged attack, +6d4 cold damage, target must save with -4 penalty or be freezed for 4 seconds.

Guided Arrow
Hunting and fighting during the night and in the deepest darkness is a necessary skill to any daughter of the Amazon islands. Devoted disciples of Athulua can, with great difficulty and strict discipline, train themselves to fire their arrows at targets blindly, as if the hand of Athulua herself guided the arrows. As might be imagined, this is an art that the Sisters of the Sightless Eye have long envied and yet have never replicated. 
This skill imbues an arrow with the ability to seek its nearest target in 30 ft. The arrow may seek back and attack again when it pierces the target, and totally gives 3-6 hits. A next skill can be casted immediately after Guided Arrow lauches. Can be learned at LV10.
  LV10: 1d8+6 damage per hit; LV15: 1d8+7 damage per hit; LV20: 1d8+8 damage per hit; LV25: 1d8+9 damage per hit.

Immolation Arrow
Hefaetrus will sometimes bestow this ability to his greatest champions. These fire-instilled arrows burn with such a fierce intensity that the very earth surrounding where they impact ignites into flame. Although the fires last but a few moments, some say the effect is as if the pillars of the mighty kingdom of Hefaetrus were reaching up through the ground to strike down the enemies who linger nearby. 
This skill enchants arrows to explode on impact, which leaves a patch of fire on the ground for 4 seconds. Enemies passing through the flames take additional damage. Successfully saving vs. breath will reduce the fire damage to half. Skill duration: 2 rounds. High-level skill.
  LV1: +2 bonus to ranged attack, immediate fire damage of 4d8, and burning damage of 1d8+2 per second; LV25: +3 bonus to ranged attack, immediate fire damage of 5d8, and burning damage of 1d8+4 per second; LV30: +4 bonus to ranged attack, immediate fire damage of 6d8, and burning damage of 1d8+6 per second; LV35: +5 bonus to ranged attack, immediate fire damage of 7d8, and burning damage of 1d8+8 per second; LV40: +6 bonus to ranged attack, immediate fire damage of 8d8, and burning damage of 1d8+10 per second.

Strafe
Once a warrior has attained this facility, she can fire a volley of arrows with amazing speed and precision, striking one target after another. Veteran mercenaries often tell a tale of a new recruit who was nearly struck down in battle because he was too distracted when first seeing an Amazon use this ability. Do not doubt his word, as he is probably referring to himself. Just smile and buy him another tankard of ale. 
With this skill the Amazon can fire a volley of arrows at multiple targets in 30 ft. Skill duration: 1 round. High-level skill.
  LV1: 1d6+6 damage per arrow; LV25: 1d6+7 damage per arrow; LV30: 1d6+8 damage per arrow; LV35: 1d6+9 damage per arrow; LV40: 1d6+10 damage per arrow.

Freezing Arrow
The greatest of the powers attained by those dedicated to Karcheus is the skill to imbue their arrows with the freezing power of a devastating avalanche. Enemies within the impact of a freezing arrow are frozen in their tracks and feel crushing pain, as if a mass of magical ice had toppled onto them. 
This skill enchants arrows to deliver cold damage that freezes any enemies near the point of impact unless they save vs. breath. Successfully saving vs. breath also reduces the cold damage to half. Skill duration: 2 rounds. High-level skill.
  LV1: +2 bonus to ranged attack, cold damage of 4d6, enemies must save vs. breath with -1 penalty or be freezed for 2 second; LV25: +3 bonus to ranged attack, cold damage of 5d6, enemies must save vs. breath with -2 penalty or be freezed for 3 seconds; LV30: +4 bonus to ranged attack, cold damage of 6d6, enemies must save vs. breath with -3 penalty or be freezed for 4 seconds; LV35: +5 bonus to ranged attack, cold damage of 7d6, enemies must save vs. breath with -4 penalty or be freezed for 5 seconds; LV40: +6 bonus to ranged attack, cold damage of 8d6, enemies must save vs. breath with -5 penalty or be freezed for 6 seconds.

*Spear, Bow and Crossbow Skills with durations can not take effect together with each other. Each of them will directly replace a pre-casted one.


----------VERSION HISTORY----------

V0.9  New mechanism for Dodge, Avoid, and Evade, no longer needs any script.
  Fixed the problem that some High-level skills have wrong effective areas after LV40.
  Party rest no longer sends the Valkyrie back, but a talk with her does.
  Adjusted the compatibility with other Diablo2 kits for no EE games.

V0.8  Fixed the problem that Black Pit game may run unsmoothy with Amazon in team.
  Another skill can be casted immediately after a Javelin skill. 
  Inner Sight now lightens enemies shortly in certain range. 
  Poison Javelin and Lightning Bolt now affect enemies on the whole traverse route but with less damage. 
  Impale now reduces about 30% of attacks of each round.
  Fixed the problem that Valkyrie does not interact with Amazon after game saving and loading.
  Some high-level skills get one more enhancement at LV40.
  Some skills are too powerful so a saving vs. breath that reduces skill effects is imposed.

V0.7 Now Valkyrie only follows her summoner across different areas, and no longer overlaps any party member (she will voluntarily take one step away). 
  A little damage decrease of Cold Arrow and Freezing Arrow.
  Decoy is no longer selectable. 
  AOE skills now ignore the protection of Mirror Image spell (EE only).
  More detailed descriptions of skills from original Diablo2. 

V0.6 Supports IWDEE.
  Fixed the game crash when summoning Valkyrie.
  Added some animations from Diablo2.
  A little increase of probability of Dodge and Avoid.
  Increased Lightning Fury, the denser the enemy crowds, the more damage it does.
  Detailed descriptions of skills are shown in EE games now.

V0.5 Fixed some details to fit EE games.
  Fixed the BUG that Penetrate can not be learned.
  A Valkyrie strictly follows the summoner (not other teammates) across different areas.
  Multiple Shot can only shoot once now, while its performance is enhanced. 
  Another skill can be casted immediately after Guided Arrow and Multiple Shot. 
  Passive skills are learned automatically with Visual Effects under feet instead of learned by clicking skill buttons.

V0.4 Amazon can wear chain mail armor, but not full plate or plate mail armors.
  Fixed the problem that a Decoy with Dodge and Avoid level is unable to stay out of physical and magic attacks.
  Removed Valkyrie's magic resistance.
  Faster HP Regeneration of Decoy and Valkyrie.
  Decoy and Valkyrie are immune to Horror, Charm, Confusion, Feeblemindedness and Unconsciousness.
  Decreased the chance that a Valkyrie stuck with other creatures that follow the team across different areas.
  Fixed the problem that Pierce never disappears once learned.
  When selected, Valkyrie can enter an inactive mode by press "C", and quit the mode by press "C" again. In the inactive mode, she'll not attack enemies initiatively unless get close and attacked by them.
  There's no more casting time or casting interval for passive spells which allow the Amazon to enter an offensive mode, e.g. Jab and Magic Arrow.

V0.3 Supports EE and original BG2. Unsuperposable Amazon skills in EE is treated as official spells: the later casted spell directly replace the previous one; while in original BG2, a later spell can only be wasted before the expiring of a previous one.
  Fixed the problem of missing chances to learn Dodge and Avoid when starting game directly at TOB.
  Dodge grants 6% chance at each learning to stay out of all physical attacks.
  Avoid grants 8% chance at each learning to stay out of all spells of offensive damage.
  Evade nolonger increases your Magic Resistance, yet grants 10% chance at each learning to stay out of all spells of magic attack, battle ground and disabling.
  Yet the new Avoid and Evade give a huge glowing white wiffle ball animation, so a new component for choosing is added to turns off the animation. (This component comes from the Ease of Use Mod Pack, which also turns off the animation for Spell Trap spell and Cloak of Mirroring.)
  Decoy gains a slightly longer duration (2 rounds).

V0.2 The bug that Immolation Arrow, Strafe and Freezing Arrow can't be learned is fixed.
  Valkyrie's Level, HP and equipments grow faster. On level 40 the Amazon will get a max-level Valkyrie with +5 equipments.
  Immolation Arrow will burn on ground instead of on enemies.
  Damage and max hits of Guided Arrow are increased by 1.

V0.1 Finished the Amazon kit.
