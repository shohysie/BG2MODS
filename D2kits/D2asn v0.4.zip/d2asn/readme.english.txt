////////////////////////////////////////////////////
////Diablo2 Kit Pack - The Assassin Ver 0.4//////
////////////////////////////////////////////////////

----------ATTENTIONS----------

  It is a Thief kit for BG2, BGT and EE series.

  Only one Assassin is suggested in a whole game, or their skills will be in conflict.

  In order that key characters not be killed by Death Sentry (which makes Quests uncompletable), Shadow Warrior and Shadow Master switch to a defensive mode by press D, and return to normal mode by press N while on selection. In the defensive mode, they'll not attack enemies initiatively unless get closed and attacked.
  Shadow Warrior and Shadow Master do not occupy the limited quantity of summoned units, but when there're already five summoned units, they can't be summoned. If a shadow is imprisoned or petrified, a reverse magic is required to free it, or else it can't be summoned again.

  Assassin gains one 'Skill Point' each level until 3,000,000 exp, player can get one skill that you like to learn by consuming each 'Skill Point'.
  *If you do press a 'Skill Point' at skill table but then close the arisen skills table without making a choice, the 'Skill Point' does nothing by get wasted!
  Some skills do not appear at low level. Maybe you'd store the 'Skill Points' up to high level to purchase powerful skills.

  For Charge-up Skills in Martial Arts, extra prompts e.g. pause or display string on head, can be triggered for the condition that accumulated charges are ready. Press S when Party AI On to switch among those prompts.

  Weapon Block gives a huge glowing white wiffle ball animation, so there's an extra component to turns off the animation. (This component comes from the Ease of Use Mod Pack, which also turns off the animation for Spell Trap spell and Cloak of Mirroring.)

  A component is also added to extend level limits of corpse explosion of Death Sentry to LV.32 for players of Legacy of Bhaal mode.

----------KNOWN BUGS----------

  Strange problems may occur on Charge-up Skills, a rest can restore all of them.

  Assassin's skills may be conflict with MOD items which have immunity from 'Removal: Remove Secondary Type'. Such problem does not exist in EE games.

----------DETAILED DESCRIPTION----------

Assassin
  The Assassins are an ancient order originally founded by the Vizjerei to hunt down and eliminate rogue mages within their own ranks. Employing secret disciplines to combat and resist the magical abilities of their elusive quarry, the Assassin's bag of tricks includes traps and other infernal devices, martial arts, and powerful mental abilities. Common people know nothing of the Assassins, but they are widely feared and respected by all who employ the magic arts. 

Advantages:
- Has three skill trees: Martial Arts, Shadow Disciplines, and Traps.
(For Charge-up Skills in Martial Arts, extra prompts e.g. pause or display string on head, can be active for the condition that accumulated charges are ready. Press S when Party AI On to switch among those prompts.)
- +25% bonus to Open Locks and Hide in Shadows at start.
- Immune to fear, charm and domination.
- +0.5 attak per round at level 1 and level 15.
- Setting traps will surely succeed no matter how many points are put on Trap Setting.
- Can specialize in any melee weapon that a thief can use.
- Automaticly get 2 slots on Two Weapon Style at start.

Disadvantages:
- No backstab multiplier.
- May not learn high-level skills of original Theives except Use Any Item.
- Unable to dual class.


Martial Arts

Tiger Strike (Charge-up Skill): 
Through extensive training in human, animal, and demonic anatomies, Assassins have developed the ability to perceive natural points of weakness in their foes and target these locations for especially devastating attacks. Charges of Tiger Strike will increase the physical damage of release attack. Can be learned after LV1.
  LV1: +8 melee damage for each successful charge; LV5: +14 melee damage for each successful charge; LV10: +20 melee damage for each successful charge; LV15: +26 melee damage for each successful charge; LV20: +32 melee damage for each successful charge.

Dragon Talon (Finishing Move): 
An Assassin is taught to utilize his entire body as a weapon-using this skill, he lets loose a powerful kick to send his opponents flying. This skill increases melee attacks for 4 rounds. Can be learned after LV1.
  LV1: attack 2 times per round, +2 to melee attack, +1 to melee damage; LV5: attack 3 times per round, +4 to melee attack, +2 to melee damage; LV10: attack 4 times per round, +6 to melee attack, +3 to melee damage; LV15: attack 5 times per round, +8 to melee attack, +4 to melee damage.

Fists of Fire (Charge-up Skill): 
Combining his powerful Martial Arts abilities with his psychic training, an Assassin can charge his own fists with pyrokinetic energies, scorching his opponents when the charge is released. One charge of Fists of Fire will add fire damage to release attack; two charges will cause an explosion of 10' radius on release attack; three charges will raise an fire wall of 10' radius for 4 seconds on release attack.  Can be learned after LV5.
  LV5: 4d8 fire damage; LV10: 6d8 fire damage; LV15: 8d8 fire damage; LV20: 10d8 fire damage.

Dragon Claw (Finishing Move):
This skill allows the Assassin to try to finish his opponent off with a rending double claw attack. In 4 rounds the Assassin's melee attack frequency is doubled. Can be learned after LV5.
  LV5: +3 to melee attack, +2 to melee damage; LV10: +4 to melee attack, +3 to melee damage; LV15: +5 to melee attack, +4 to melee damage; LV20: +6 to melee attack, +5 to melee damage.

Cobra Strike (Charge-up Skill):
A properly trained Assassin can focus his mind to draw upon the ambient energies surrounding her. Using this skill, he can drain his adversary of life and spiritual essence. Charges of Cobra Strike will give ability to recover HP and chance to restore all skills on release attack. Can be learned after LV10.
  LV10: 2d8 HP and 2% chance to restore skills per charge; LV15: 4d8 HP and 4% chance to restore skills per charge; LV20: 6d8 HP and 6% chance to restore skills per charge; LV25: 8d8 HP and 8% chance to restore skills per charge.

Claws of Thunder (Charge-up Skill):
Using his weapon's metal blades as conductors, an Assassin charges the ions surrounding him and delivers a devastating lightning attack to any who dare challenge her. One charge of Claws of Thunder will add electricity damage to release attack; two charges will cause a nova of 30' radius on release attack; three charges will spread multiple charge bolts on release attack. Can be learned after LV15.
  LV15: 2d20 electricity damage; LV20: 3d20 electricity damage; LV25: 4d20 electricity damage; LV30: 5d20 electricity damage.

Blades of Ice (Charge-up Skill):
Charging the ether around his claw blades, the trained Assassin can chill opponents with a vicious rake of his razors. One charge of Blades of Ice will add cold damage to release attack which also slows the enemy; two charges will damage and slow enemies in 10' radius on release attack; three charges will damage and freeze enemies in 10' radius on release attack. Can be learned after LV20. 
  LV20: 4d4 cold damage, slow or freeze for 1 second; LV25: 6d4 cold damage, slow or freeze for 2 seconds; LV30: 8d4 cold damage, slow or freeze for 3 seconds; LV35: 10d4 cold damage, slow or freeze for 4 seconds.

Dragon Tail (Finishing Move):
The experienced Assassin can deliver a strike so powerful it actually causes an explosion on impact, sending any nearby victims sprawling. In 4 rounds each successful melee attack will cause an explosion of 10' radius. The victim(s) may make a save vs. death to take only half damage. Can be learned after LV15.
  LV15: +3 to melee attack, 10-14 fire damage; LV20: +4 to melee attack, 14-18 fire damage; LV25: +5 to melee attack, 18-22 fire damage; LV30: +6 to melee attack, 22-26 fire damage.

Dragon Flight (Finishing Move):
After years of disciplined physical conditioning, an Assassin can develop the ability to move faster than the eye can follow in one quick burst. Using this skill, he lunges at his target and delivers a devastating strike. The victim may make a save vs. death in order to take only half damage. Can be learned after LV20.
  LV20: 6d10 crushing damage; LV25: 8d10 crushing damage; LV30: 10d10 crushing damage; LV35: 12d10 crushing damage.

Phoenix Strike (Charge-up Skill):
This mighty skill allows the Assassin trained in its arts to prepare an attack that gives off powerful elemental energies. One charge of Phoenix Strike will call a meteor on release attack which continues burning on ground for 4 seconds; two charges will caster chain lightning on release attack; three charges will spread chaos ice bolts, which freeze enemies in 30' radius for 3 seconds on release attack. High-level skill.
  Before LV30: 7d8 fire damage by meteor and burns for 1d4 fire damage per second, 3d20 electricity damage for chain lightning, 7d6 cold damage for chaos ice bolt;
  LV30: 8d8 fire damage by meteor and burns for 1d6 fire damage per second, 4d20 electricity damage for chain lightning, 8d6 cold damage for chaos ice bolt;
  LV35: 9d8 fire damage by meteor and burns for 1d8 fire damage per second, 5d20 electricity damage for chain lightning, 9d6 cold damage for chaos ice bolt;
  LV40: 10d8 fire damage by meteor and burns for 1d10 fire damage per second, 6d20 electricity damage for chain lightning, 10d6 cold damage for chaos ice bolt.

*A Charge-up Skill is an attack that adds a 'charge' for each successive hit within 9 seconds. While each Charge-up attack deals normal damage, the charges continue to accumulate, up to 3 charges for each Charge-up Skill. A Charge-up Skill finishes when the 9 seconds exhaust or a Finishing Move is casted, at this time an Assassination effect icon is shown on the Assassin's portrait, which means the accumulated charges are ready to be triggered by a melee attack (each successful charge will +1 to hit on this attack only). The accumulated charges disappear immediately after being triggered, or disappear after 4 rounds if no successful melee attack is done.
 By casting another Charge-up Skill before a previous one exhausts, Assassins can build up a succession of different Charge-up Skills and generate a potent combination of effects.
 While a Charge-up Skill is active, a Contingency effect icon is shown on the Assassin's portrait. This icon disappears just 1 second before the Charge-up Skill expires, which reminds that the Charge-up Skill will exhaust, and it's time to cast another Charge-up Skill or trigger the accumulated charges at a worthy enemy.
 Extra prompts e.g. pause or display string on head, can be active for the condition that accumulated charges are ready. Press S when Party AI On to switch among those prompts.
 A Finishing Move doesn't just stop Charge-up Skills or make the Assassin able to trigger the accumulated charges, it also adds a powerful effect of its own. Yet its effect disappears immediately while another Charge-up Skill is casted.
 Different Finishing Moves can not take effect together with each other, each of them will directly replace a pre-casted one. Different Charge-up Skills will also replace a pre-casted one, although the accumulated charges are kept.


Shadow Disciplines

Claw Mastery:
Well-disciplined training in this skill improves the artistry with which an Assassin wields his melee weapons. Assassin can gain +1 to melee attack and damage at every 5 levels.

Psychic Hammer:
By utilizing his intense mental prowess, an Assassin creates a powerful force of mental energies and directs it towards a hostile creature, blasting it backwards. And another skill can be casted immediately after a Psychic Hammer.
  LV1: 1D4 magic damage;  LV5: 2D4 magic damage;  LV10: 3D4 magic damage;  LV15: 4D4 magic damage. 

Burst of Speed:
Increases attack and movement speed for a period of time, as with the spell Haste. Can be learned after LV5.
  LV5: duration 2 turns. LV10: duration 3 turns. LV15: duration 4 turns. LV20: duration 5 turns.

Cloak of Shadows:
Moving through the darkness, unseen by his foes, the enshrouded Assassin can steal past opponents or ambush his unsuspecting victims with devastating attacks. Cloak of Shadows make the Assassin invisibile and offers some AC bonus. This skill also gives some AC penalty to all enemies nearby and force them to save vs. death to avoid becoming blind. Can be learned after LV10.
  LV10: +2 AC to the Assassin and -2 AC to enemies nearby, requires saving with -1 penalty to avoid becoming blind, all effects have a duration of 2 rounds; LV15: +3 AC to the Assassin and -3 AC to enemies, requires saving with -2 penalty, duration 3 rounds; LV20: +4 AC to the Assassin and -4 AC to enemies, requires saving with -3 penalty, duration 4 rounds; LV25: +5 AC to the Assassin and -5 AC to enemies, requires saving with -4 penalty, duration 5 rounds.

Weapon Block:
After developing this skill, an Assassin wielding two Claw-class weapons can use his blades to deflect incoming attacks, thus giving herself a defensive edge without using a shield. While equipping two weapons, the Assassin get +2 AC to all 4 types of weapons (Crushing, Missile, Piercing and Slashing) and +6% chance per skill level to block physical attacks and spells of offensive damage. Can be learned for 6 times. High-level skill.

Fade:
An Assassin can will his physical being to shift partially into the astral planes. As his body becomes less substantial, he becomes less susceptible to the effects of elemental attacks and immune to poison and cursed equipments. Magicial curses such as Doom and Greater Malison are also resisted. Can be learned after LV15.
  LV15: +20% resistances to elemental damage, +5% resistance to physical damage, duration 2 turns; LV20: +30% resistances to elemental damage, +10% resistance to physical damage, duration 3 turns; LV25: +40% resistances to elemental damage, +15% resistance to physical damage, duration 4 turns; LV30: +50% resistances to elemental damage, +20% resistance to physical damage, duration 5 turns.

Shadow Warrior:
The Assassin trained in this discipline has the ability to project a 'shadow' of herself. The Shadow Warrior only makes use of physical attack and Martial Arts. It gains the same level as its summoner, and is equipped with +2 enchanted short sword which gain +1 enchantment when reaches level 20, 25 and 30. Shadow Warrior gains bonuses equal to the summoner in Claw Mastery and Weapon Block. The Shadow can follow the summoner across different areas and attack any enemy. it remains under the caster's control until destroyed in combat or when party rests. Only one Shadow can exist, the pre-summoned one will disappear when another on is summoned. The Shadow does not occupy the limited quantity of summoned units, but when there're already five summoned units, it can't be summoned. Can be learned after LV15.
Shadow Warrior switches to a defensive mode by press D, and returns to normal mode by press N while on selection. In the defensive mode, it'll not attack enemies initiatively unless get closed and attacked.
Talk with the Shadow and you can send it back.

Mind Blast:
Focusing his anima, an Assassin using this potent ability can crush the will of a group of enemies, stunning them for 2 seconds and confusing the feebleminded into attacking their comrades. Can be learned after LV20.
  LV20: 2d6 damage, 20% chance to convert; LV25: 3d6 damage, 25% chance to convert; LV30: 4d6 damage, 30% chance to convert; LV35: 5d6 damage, 35% chance to convert. 

Venom:
Poison use is another technique an Assassin has to help even the odds when battling demons and their ilk. An Assassin who has mastered this skill secretly coats his weapons with vile toxins. This skill lasts for 1 turn, during which all sufferers hit by the Assassin are posioned for 1 round. This skill also works on strikes of Blade Sentinel, Blade Fury and Blade Shield. High-level skill.
  Before LV30: 3 poison damage per second; LV30: 4 poison damage per second; LV35: 5 poison damage per second; LV40: 6 poison damage per second.

Shadow Master:
This discipline allows an Assassin to project an even more powerful shadow avatar. The Shadow Master has access to all of the Assassin skills, also skills you don't have yet. It gains the same level as its summoner, and is equipped with +3 enchanted short sword which gain +1 enchantment when reaches level 30, 35 and 40. Shadow Master gains bonuses equal to the summoner in Claw Mastery and Weapon Block. The Shadow can follow the summoner across different areas and attack any enemy. It will remain under the caster's control until destroyed in combat or when party rests. Only one Shadow can exist, the pre-summoned one will disappear when another on is summoned. The Shadow does not occupy the limited quantity of summoned units, but when there're already five summoned units, it can't be summoned. High-level skill.
Shadow Master switches to a defensive mode by press D, and returns to normal mode by press N while on selection. In the defensive mode, he'll not attack enemies initiatively unless get closed and attacked.
Talk with the Shadow and you can send it back.

*Burst of Speed and Fade can not take effect together with each other, each of them will directly replace a pre-casted one.
*Only one of Shadow Warrior and Shadow Master can exist. The pre-summoned one will disappear when another on is summoned.


Traps

Fire Blast:
This skill gives an Assassin the ability to manufacture and throw a small incendiary device. This ordinance explodes when an enemy approaches, damaging any foe within a small blast radius of 8'. The fire damage increases at 1d8 per caster level until LV20. The victim(s) may make a save vs. death in order to take only half damage.
  LV1: requires saving with -1 penalty; LV5: requires saving with -2 penalty; LV10: requires saving with -3 penalty; LV15: requires saving with -4 penalty; LV20: requires saving with -5 penalty.

Shock Web:
These traps comprise a collection of small conductive components that arc electricity between one another, damaging any opponents who tread upon them. The arc jumps for 3 seconds, strikes enemies in 10' for 1d4 electric damage per second per caster level until LV20. The victim(s) may make a save vs. death in order to take only half damage. This trap does not occupy the limited quantity of active traps. Can be casted after LV5.
  LV5: requires saving with -1 penalty; LV10: requires saving with -2 penalty; LV15: requires saving with -3 penalty; LV20: requires saving with -4 penalty.

Blade Sentinel:
This skill allows the Assassin to create a razor-sharp device that bounces when intersects with a wall and damages all enemies on its road. 40 blades with a basic damage of 1D4 are created in the weapon slot and exist for 10 turns. Can be learned after LV5.
  LV5: +1 blade, the Assassin is regarded to have two proficiency slots on this weapon; LV10: +2 blade, three proficiency slots; LV15: +3 blade, four proficiency slots; LV20: +4 blade, five proficiency slots.

Charged Bolt Sentry:
This small device, once cast upon the ground, emits charges of electricity that shock any adversary who strays too close. Each victim in the area may be hit by 1-3 charge bolts at the same time. The victim(s) may make a save vs. death in order to take only half damage. This sentry will vanish after 5 attacks or 60 seconds. Can be casted after LV10.
  LV10: 2D6 electricity damage for each charge bolt, requires saving with -1 penalty;  LV15: 2D8 electricity damage, requires saving with -2 penalty;  LV20: 2D10 electricity damage, requires saving with -3 penalty;  LV25: 2D12 electricity damage, requires saving with -4 penalty.

Wake of Fire:
Once erected, this trap releases waves of flame that incinerate any opponents within its path. The victim(s) may make a save vs. death in order to take only half damage. This sentry will vanish after 5 attacks or 60 seconds. Can be casted after LV10.
  LV10: 4D6 fire damage, requires saving with -1 penalty;  LV15: 5D6 fire damage, requires saving with -2 penalty;  LV20: 6D6 fire damage, requires saving with -3 penalty;  LV25: 7D6 fire damage, requires saving with -4 penalty.

Blade Fury:
Using this skill, the Assassin throws split blades, each straight hit on the opponent will launch an additional blade, shredding all his enemies on the flying trail. A total of 40 blades with a basic damage of 1D4 are created in the weapon slot and exist for 10 turns. Can be learned after LV15.
  LV15: +2 blade, the Assassin is regarded to have two proficiency slots on this weapon; LV20: +3 blade, three proficiency slots; LV25: +4 blade, four proficiency slots; LV30: +5 blade, five proficiency slots.

Lightning Sentry:
This device discharges great bolts of electricity, frying assailants when they come near. The victim(s) may make a save vs. death in order to take only half damage. This sentry will vanish after 8 attacks or 60 seconds. Can be casted after LV20.
  LV20: 4D6 electricity damage, requires saving with -1 penalty;  LV25: 4D8 electricity damage, requires saving with -2 penalty;  LV30: 4D10 electricity damage, requires saving with -3 penalty;  LV35: 4D12 electricity damage, requires saving with -4 penalty.

Wake Of Inferno:
Once an Assassin throws it to the ground, this trap expels a large spout of fire at any opponent who moves within its range. The victim(s) may make a save vs. death in order to take only half damage. This sentry will vanish after 8 attacks or 60 seconds. Can be casted after LV20.
  LV20: 3D8 fire damage, requires saving with -1 penalty;  LV25: 4D8 fire damage, requires saving with -2 penalty;  LV30: 5D8 fire damage, requires saving with -3 penalty;  LV35: 6D8 fire damage, requires saving with -4 penalty.

Death Sentry:
This trap emits projectiles laden with a potent chemical catalyst, detonating the exposed cadavers of enemies. The victim must save vs. spell with -2 penalty or dies and gives an explosion of 12 feet in radius. All hostile creatures in the area of explosion will suffer 1d8 damage (8d8 at least, half in fire and half in crushing, save vs. death for half damage) per hit dice of the victim. Corpse explosion affects undead and construct creatures as well, but can't affect targets beyond level 20. This sentry also releases lightning bolts to attack enemies (no save is need). This sentry will vanish after 5 attacks or 60 seconds. Can be casted after LV25. 
  LV25: 2D6 electricity damage for the lightning bolt;  LV30: 2D8 electricity damage;  LV35: 2D10 electricity damage;  LV40: 2D12 electricity damage.

Blade Shield:
This contrivance releases several small razors and uses magnetic forces to set them spinning about the Assassin, inflicting grievous wounds on any foe who approaches him too closely.  The victim(s) may make a save vs. death in order to take only half damage. High-level skill.
  Before LV30: 6D6 slashing damage, requires saving with -1 penalty, last for 6 rounds; LV30: 6D8 slashing damage, requires saving with -2 penalty, last for 8 rounds; LV35: 6D10 slashing damage, requires saving with -3 penalty, last for 10 rounds; LV40: 6D12 slashing damage, requires saving with -4 penalty, last for 12 rounds.

*No matter how you choose from Charged Bolt Sentry, Wake of Fire, Lightning Sentry, Wake Of Inferno and Death Sentry, there's a total limit of five active traps. The first trap will be destroyed when a sixth trap is set.

----------VERSION HISTORY----------

V0.4 For Charge-up Skills in Martial Arts, extra prompts e.g. pause or display string on head, can be active for the condition that accumulated charges are ready. Press S when Party AI On to switch among those prompts.
     Hot keys of Shadow Warrior and Shadow Master are set to D (Defence) and N (Normalize). 
     Fix the problem that mechanism of Charge-up Skill may be out of order in case that no attack is made before a Charge-up Skill expires or a Finishing Move is casted before a Charge-up Skill. If there're still some accidental problems, a party rest can solve all of them.
     Blade Sentinel and Blade Fury can hurt all enemies on their flight path on the premise that the blade hits a target. When Blade Sentinel intersects with a wall it will bounce and keep offensive.
     Weapon Block boosts the defense against all 4 types of weapons (Crushing, Missile, Piercing and Slashing) so that AC bonus can continue accumulating when base AC reaches limit of -20.
     In order to avoid getting jammed when traveling across different areas, a Shadow voluntarily takes one step away from the Assassin when they get too close. 
     Solved the problem that Weapon Block do not keep current levels when character is exported and imported or enter a TOB game from SOA.
     The lower limit of corpse explosion of Death Sentry is set to 8D8, as some enemies in the game don't have correct class levels.
     There'd be an animation of leeching mana when a Cobra Strike restore Assassin's skills successfully.
     Resolved the possible conflict in no EE games between this kit and the Diablo2 Druid kit.
     The Assassin no longer keeps invisible on casting traps and other hostile skills.
     A Shock Web can give 3 attacks in 3 seconds, but with a less attack range.
     Total Amout of Extra Skill Points in High-level skills reduced to 5 from 10.
     Venom works on strikes of Blade Sentinel, Blade Fury and Blade Shield.
     AOE skills now ignore the protection of Mirror Image spell (EE only).
     Party rest no longer sends a Shadow back, but a talk with him does.
     New mechanism for Charge-up Skills, less burden for global script.
     Shadow Warrior and Shadow Master no longer bring potions.
     Fixed the faulty skills of Shadow Warrior and Shadow Master.
     Fixed transparency of some animations for no EE games.
     Adjusted the values and save penalty of many skills.
     Active traps can be triggered by invisible enemies.
     Immune to fear, charm and domination at start.
     Fixed the limit of active traps from six to five.
     Removed the noise of Blade Shield.

V0.3 Fixed a lot of BUGs on Charge-up Skills.
 The Assassin is no longer forced to stop all actions when Charges are ready. Now the Contingency effect icon on the Assassin's portrait disappears just 1 second before the Charge-up Skill expires, which reminds that the Charge-up Skill will exhaust.
 Fixed the problem that Claws of Thunder can't be learned.
 Changed the icons of Blade Sentinel and Blade Fury.
 Added some animations and sounds from Diablo2.
 When the Assassin learns a new Weapon Block skill level, an animation appears under his feed to reduce icons appearing on skill table.
 A trap is gained on every 4 levels instead of 3.
 Mind Blast can be caster on the ground now.
 The Shadow Master now set a trap on every 2 rounds instead of 1.
 The Shadow Warrior or Shadow Master now only follows the summoner instead of other teammates.
 Meteor of Phoenix Strike now delays 2 seconds before hitting the ground. BUG of missing fire wall of a meteor is fixed.
 Weapon Block can be learned for 6 times now.
 Fire Blast can be set on ground just like other traps. Its Damage type is also fixed. 
 Another skill now can be casted immediately after a Psychic Hammer.
 The Assassin now becomes transparent with the Fade skill.
 Detailed descriptions of skills are shown in EE games now.

V0.2 Optimised for EE.
 Shadow Master will no longer cast a lot of traps.
 In order that key characters will not killed by Death Sentry (which makes the quests uncompletable), Shadow Warrior and Shadow Master can enter an inactive mode by press C and quit the mode by press C again when selected. In the inactive mode, they'll not attack enemies initiatively unless get close and attacked by them.
  Fixed the problem that Extra Skill Points in High-level skills lost their icons.

V0.1 Finished the Assassin kit.
