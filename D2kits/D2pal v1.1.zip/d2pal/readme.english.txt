////////////////////////////////////////////////////
/////Diablo2 Kit Pack - The Paladin Ver 1.1/////////
////////////////////////////////////////////////////

----------ATTENTIONS----------

  It is a Paladin kit for BG2, BGT and EE series.

  Paladin gains various auras at different levels. The auras, which take effect each round, can be switched freely.
  Auras against the enemy need to be actually triggered by an enemy in the Paladin's sight. Auras for the whole team take effect on the Paladin himself instantly when activated, but the area effect needs to be triggered by anyone within 50' of the Paladin. Exceptions: Meditation, Redemption and Thorns actually work on battle, they only give visual effects in normal times, because the former two Auras are too powerful, and the last Aura may cause problems on cutscenes, etc.

  Paladin gains one 'Skill Point' each level until 3,000,000 exp, player can get one Combat Skill that you like to learn by consuming each 'Skill Point'.
  *If you do press a 'Skill Point' at skill table but then close the arisen skills table without making a choice, the 'Skill Point' does nothing by get wasted!
  Some skills do not appear at low level. Maybe you'd store the 'Skill Points' up to high level to purchase powerful skills.

  Holy Shield gives a huge glowing white wiffle ball animation, so there's an extra component to turns off the animation. (This component comes from the Ease of Use Mod Pack, which also turns off the animation for Spell Trap spell and Cloak of Mirroring.)

----------KNOWN BUGS----------

  Paladin's skills may get problems in case that MOD items which have immunity from 'Removal: Remove Secondary Type' are equipped. 
  This bug does not exist in EE games.
  If you enter the Character sheet without pausing the game, auras may temporarily work wrong (a BUG of the game itself). 

----------DETAILED DESCRIPTION----------

Paladin
The Knights of Westmarch who felled the armies of mighty Leoric are pure at heart and closely follow the teachings of Zakarum, the Religion of the Light. A battle-ready warrior for whom faith is a shield, the Paladin fights for what he believes to be right. His steadfastness gives him powers to bestow blessings to his friends and wreak cruel justice on foes. There are those who call the Paladin an overwrought zealot, but others recognize in him the strength and goodness of the Light. 

Advantages:
-  Has three skill trees: Defensive Auras, Offensive Auras and Combat Skills.
-  Automaticly get two slots on sword and shield class at start.

Disadvantages:
-  May not use 'lay on hands' ability.
-  May not cast priest spells.
-  May not turn Undead.
-  Only can put one slot on single weapon, two weapon and two handed class.
-  Only can be proficient in two-handed weapons and ranged weapons.
-  May not learn high-level skills of original Paladins.


Defensive Auras

Prayer
With this aura the Paladin basks himself and all he deems faithful in a warm, healing light. His prayers for salvation carry him through the direst situations, allowing him to heal even the deepest wounds in time. 
This aura gives all party members ability of regeneration. Required Level: 1
  LV1: regenerates 2 HP/round; LV5: regenerates 4 HP/round; LV10: regenerates 6 HP/round; LV15: regenerates 8 HP/round.

Resist Fire
Shrouding himself in his devotions, the fervent servant of the Light can walk a lake of fire and feel only the comforting warmth of his convictions. A Paladin can withstand the might of a fierce conflagration if his piety is strong enough. 
This aura increases the fire resistance of all party members. Required Level: 1
  LV1: +45% Fire resistance; LV5: +60% Fire resistance; LV10: +75% Fire resistance; LV15: +90% Fire resistance.

Resist Cold
The splendor of absolute devotion is all the warmth and comfort a Paladin requires. Embraced deep within the shelter of this aura, the faithful need never fear the frost. 
This aura increases the cold resistance of all party members. Required Level: 5
  LV5: +45% Cold resistance; LV10: +60% Cold resistance; LV15: +75% Cold resistance; LV20: +90% Cold resistance.

Resist Lightning
Even the elements of nature must yield before the glory of the Light. When a knight of Zakarum has manifested this aura, he and his allies undergo a lessening of their body's natural conductivity, protecting them from attacks empowered by electricity. 
This aura increases the lightning resistance of all party members. Required Level: 10
  LV10: +45% Lightning resistance; LV15: +60% Lightning resistance; LV20: +75% Lightning resistance; LV25: +90% Lightning resistance.

Defiance
Shielding himself and nearby companions within a glow of holy light, the Paladin girds himself to face the unjust in combat. By standing resolute and earnest in the face of opposition, his faith is his shield against harm. 
This aura boosts the defense against all 4 types of weapons (Crushing, Missile, Piercing and Slashing) for all party members. Required Level: 5
  LV5: +4 Bonus to all AC types; LV10: +5 Bonus to all AC types; LV15: +6 Bonus to all AC types; LV20: +7 Bonus to all AC types.

Cleansing
Chaste is the Paladin in the face of all temptations. Pure in body and spirit, he trusts to the splendor of the Light to rid him of all impurities. A Knight of the Faith shall neither be tainted, nor corrupted. 
This aura can cure poison, remove cursed items and increase acid resistance of all party members. Required Level: 10
  LV10: +45% Acid resistance; LV15: +60% Acid resistance; LV20: +75% Acid resistance; LV25: +90% Acid resistance.

Vigor
A noble knight of Zakarum feels the rapture of his salvation at all times. In his need, the weight of the world lifts from his shoulders, allowing him to march forth without heed to the lamentations of his body. 
This aura increases speed and reduces fatigue of all party members. Required Level: 15
  LV15: +5 to Speed; LV20: +6 to Speed; LV25: +7 to Speed; LV30: +8 to Speed.

Meditation
With the observance of this aura, the Paladin supplicates himself to the Light with silent utterances of prayers. It is in these times of silent worship that the Paladin is rejuvenated in spirit. 
This aura restores a casted spell per round for all party members, and also gives ability of regeneration as Prayer casted by a Paladin with a half level of the caster. Required Level: 20
  LV20: spell of level 1-3; LV25: spell of level 1-5; LV30: priest spell of level 1-6, wizard spell of level 1-7;  LV35: priest spell of level 1-7, wizard spell of level 1-9.

Redemption
A Paladin must be true to his duty and belief that all souls are worthy of attempted salvation. With this aura, the Paladin shares the glory of the Light with his vanquished enemies. With each administration of these final rites, the Paladin is redeemed physically as well as spiritually. 
With this aura, the Paladin redeems one soul per round in battle to restore a certain amount of health points, and has a chance to redeem both souls at the same time to restore all of his casted skills. High-Level skill. 
  Before LV25: 4D8 HP each round, 6% chance to recover skills; LV25: 5D8 HP each round, 8% chance to recover skills; LV30: 6D8 HP each round, 10% chance to recover skills; LV35: 7D8 HP each round, 12% chance to recover skills; LV40: 8D8 HP each round, 14% chance to recover skills.

Salvation
Trust in the glory of the Light, for its authority supercedes all power in the mortal world. With this aura, the Paladin calls upon the Light to protect his allies from elemental attacks. 
This aura increases all Elemental resistances for all party members. High-Level skill.
  Before LV25: Increases all Elemental resistance by 35%; LV25: Increases all Elemental resistance by 45%; LV30: Increases all Elemental resistance by 55%; LV35: Increases all Elemental resistance by 65%; LV40: Increases all Elemental resistance by 75%.


Offensive Auras

Might
Caught up in the fervor of battle, the Paladin calls upon the power of righteousness and the strength of justice to add force to the attacks of his party. What would be glancing blows now strike their mark, and otherwise deflected strikes rend through armor to bite flesh. 
This aura increases damage dealt by party members. Required Level: 1
  LV1: +3 damage; LV5: +4 damage; LV10: +5 damage; LV10: +6 damage.

Holy Fire
With a hint of brimstone in the air, the noble Paladin strides into battle encased in this holy aura. All those within its range are burnt with the fires of divine virtue. Beware, Beasts of Hell! The fire of purification is upon you! 
This aura periodically does Fire damage to nearby enemies, and also attaches Fire damage on Paladin's weapon. Required Level: 5
  LV5: 1-2 fire damage to nearby enemies and 2-3 fire damage on weapon; LV10: 1-3 fire damage to nearby enemies and 4-5 fire damage on weapon; LV15: 1-4 fire damage to nearby enemies and 6-7 fire damage on weapon; LV20: 1-5 fire damage to nearby enemies and 8-9 fire damage on weapon.

Thorns
An eye for an eye is sometimes not enough. Those who would strike the emissaries of the Light had best take warning, for retribution shall be swift and certain. The might of your blows shall be felt a hundred fold unto you! 
This aura causes enemies to take piercing damage when they cause melee damage to party members. Required Level: 5
  LV5: 2D6 damage; LV10: 4D6 damage; LV15: 6D6 damage; LV20: 8D6 damage.

Blessed Aim
The spirits of the Light are ever vigilant, and in times of great need, have been known to aid their loyal disciples in subtle ways. When this aura is enabled, these spirits work to guide the hand of the Paladin and his companions, striking true where blows would normally miss. 
This aura brings bonus to THAC0. Required Level: 10
  LV10: +4 bonus to THAC0; LV15: +6 bonus to THAC0; LV20: +8 bonus to THAC0; LV25: +10 bonus to THAC0.

Concentration
Those within the sphere of influence of this skill gain the gift of clarity. A serene sense of lucidity eases the minds of those within, giving them the freedom to focus on individual tasks despite the chaos and distractions of battle. This sense of tranquility allows the Paladin and his comrades to strike calculated and devastating blows. 
This aura increases attack damage and has chance to make party members immune to various negative states that interrupt their actions. Required Level: 15
  LV15: +4 damage, 20% chance of immunity; LV20: +6 damage, 30% chance of immunity; LV25: +8 damage, 40% chance of immunity; LV30: +10 damage, 50% chance of immunity.

Holy Freeze
Using this aura, the Paladin causes the temperature of the air around him to drop drastically, freezing the flesh of his enemies. Those so affected will find their movement drastically hindered and are easily dispatched back to the Hells from whence they spawned. 
This aura periodically damages and slows enemies nearby, and also attaches Cold damage on Paladin's weapon. Required Level: 15
  LV15: 1-2 cold damage to nearby enemies and 4 cold damage on weapon; LV20: 2-3 cold damage to nearby enemies and 6 cold damage on weapon; LV25: 3-4 cold damage to nearby enemies and 8 cold damage on weapon; LV30: 4-5 cold damage to nearby enemies and 10 cold damage on weapon.

Holy Shock
A Paladin blessed with the power of this aura calls upon the power of the Light to strike forth at all enemies surrounding him. Divine bolts spring from the earth to smite the Paladin's enemies. 
This aura periodically does Lightning damage to enemies within a radius, and also attaches Lightning damage on Paladin's weapon. Required Level: 20
  LV20: 1-8 Lightning damage to nearby enemies and 1-18 Lightning damage on weapon; LV25: 1-10 Lightning damage to nearby enemies and 1-21 Lightning damage on weapon; LV30: 1-12 Lightning damage to nearby enemies and 1-24 Lightning damage on weapon; LV35: 1-14 Lightning damage to nearby enemies and 1-27 Lightning damage on weapon.

Sanctuary
This aura causes the Paladin to shine with an inner, holy light. This light is an anathema to the undead, summoned as they are through the machinations of the Prime Evils. The aura carries with it the essence of life and the strength and purity of the Paladin's convictions. 
This aura damages and does knockback to the hostile Undead, and also enhances Paladin's attacks vs. Undead. Required Level: 20
  LV20: 2D4 damage to nearby Undead, and +9 damage vs. Undead; LV25: 2D6 damage to nearby Undead, and +12 damage vs. Undead; LV30: 2D8 damage to nearby Undead, and +15 damage vs. Undead; LV35: 2D10 damage to nearby Undead, and +18 damage vs. Undead.

Fanaticism
True faith can cause its believers to perform fantastic feats. With this aura the Paladin, and all those allied with his cause, carry themselves with a zealous fervor, allowing them to strike down their foes as swiftly as the scythe reaps the harvest. 
This aura increases attack rate and brings bonus to THAC0 and damage for all party members. And more damage increasing for Paladin himself. High-Level skill.
  Before LV25: +1 attack per round, +2 bonus to THAC0 and +3 to damage for party member, +6 damage to the Paladin; LV25: +1 attack per round, +3 bonus to THAC0 and +4 to damage for party member, +8 damage to the Paladin; LV30: +1 attack per round, +4 bonus to THAC0 and +5 to damage for party member, +10 damage to the Paladin; LV35: +1 attack per round, +5 bonus to THAC0 and +6 to damage for party member, +12 damage to the Paladin; LV40: +1 attack per round, +6 bonus to THAC0 and +7 to damage for party member, +14 damage to the Paladin.

Conviction
It is fearsome enough to behold the power of a Paladin, let alone a Paladin aglow with the aura of Conviction. This halo of righteousness demonstrates, with force, the grim determination of those who shine within its brilliance. Any who stand against the Paladin and his allies will understand the meaning of folly. 
This aura reduces Defense and the Resistances of enemies. High-Level skill.
  Before LV25: -4 penalty to AC, -15% to all resistances; LV25: -6 penalty to AC, -20% to all resistances; LV30: -8 penalty to AC, -25% to all resistances; LV35: -10 penalty to AC, -30% to all resistances; LV40: -12 penalty to AC, -35% to all resistances.

*There's only one active aura on Paladin. When switching to another aura, the pre-casted aura is canceled.


Combat Skills

Sacrifice
At what price glory? By sanctifying his weapon with some of his own blood, a Paladin of Zakarum is able to increase his efficiency in combat by forfeiting a portion of his own physical essence. This sacrifice is a symbol of faith that even the lowliest Paladin must submit before the Light, in order that he may prove himself worthy of victory. 
This skill increases damage at the cost of 8% health on each hit. Required Level: 1
  LV1: +9 damage, +3 bonus to THAC0; LV5: +12 damage, +4 bonus to THAC0; LV10: +15 damage, +5 bonus to THAC0; LV15: +18 damage, +6 bonus to THAC0; LV20: +21 damage, +7 bonus to THAC0.

Smite
The sword of a Paladin represents the might of righteousness and his shield symbolizes the strength of his faith. Both are tools he uses to mete out justice. Just as righteousness can give his spirit the fortitude to overcome the attacks of the unjust, so too can faith be a weapon to strike back at those who work to defeat him. To this end, the Paladin has developed several combat techniques that use the shield not only for defense, but also as an offensive weapon. 
This skill brings shield bash that does damage and stunning, allowing the Paladin to pursue immediately wtih a next skill. Required Level: 1
  LV1: 2D6 damage, stun for 1 second; LV5: 2D8 damage, stun for 1 seconds; LV10: 2D10 damage, stun for 2 seconds; LV15: 2D12 damage, stun for 2 seconds.

Holy Bolt
The Paladin can learn to summon bolts formed of pure, righteous energies. These projectiles are vessels of life, bane to the undead and demons, and succor to the faithful. At the battle of Taelohn Bridge, the villagers feared the day was lost when an army of the walking dead besieged them. Just as the battered militia was about to be overwhelmed, a small band of Paladins appeared. Wading through the rotting carcasses of the living dead and hurling spheres of pure Light that expelled the evil controlling the battling corpses while renewing the strength of the remaining villagers. 
This skill launches bolt of energy that damages hostile Undead and Demons, or heals friendly units with HP as half of damages. Required Level: 5
  LV5: 4D6 damage; LV10: 6D6 damage; LV15: 8D6 damage; LV20: 10D6 damage.

Zeal
A noble Paladin, fervent in his dedication to righteousness, can draw upon the spirit of that dedication to perform seemingly impossible tasks. When surrounded by his enemies, a Paladin versed in this skill sets upon his adversaries with the zealous fervor of many times his number. 
This skill provides quick attacks on adjacent enemies. Required Level: 10
  LV10: Attack twice per round, +1 melee damage, +2 bonus to melee THAC0; LV15: Attack 3 times per round, +2 melee damage, +3 bonus to melee THAC0; LV20: Attack 4 times per round, +3 melee damage, +4 bonus to melee THAC0; LV25: Attack 5 times per round, +4 melee damage, +5 bonus to melee THAC0.

Charge
In showing fear, a Paladin displays his lack of faith, and a faithless Paladin is less than a man - let alone a knight. This is vital in that when all else fails, it is faith that will carry the Paladin through to victory. Warriors of faith never shirk from combat, but rush forward with heads down and shields up, allowing their glory to carry them into the thick of battle to deliver the first blow. 
This ability causes the Paladin to close the distance with an enemy, delivering a bash on contact. The enemy is knocked back, which makes it easy for the Paladin to pursue with another skill immediately. The victim(s) may make a save vs. death in order to take only half damage. Required Level: 10
  LV10: 6D10 damage; LV15: 8D10 damage; LV20: 10D10 damage; LV25: 12D10 damage.

Vengeance
When a Paladin undertakes a crusade to banish evil, he is permitted to call upon the just souls of past crusades. Thus summoned, the spirits of the honorably vanquished manifest themselves and lend their energies to the weapons of the Paladin. 
This skill adds Elemental (Fire, Lightning, Cold and Acid) damage to all melee attacks. Required Level: 15
  LV15: 1D4 each elemental damage, +2 bonus to THAC0; LV20: 1D6 each elemental damage, +3 bonus to THAC0; LV25: 1D8 each elemental damage, +4 bonus to THAC0; LV25: 1D10 each elemental damage, +5 bonus to THAC0.

Blessed Hammer
The Visions of Akarat tell of a hopeless battle. Legions of the undead had laid siege to a small convent of nuns who were the keepers of a sacred relic, the Hammer of Ghrab Thaar. Suspended over a fiery chasm within the convent, the sisters knew the Hammer to be a powerful vessel of the Light and vowed never to allow it to fall into the hands of evil. With no weapons of their own, and no one to defend them, the nuns sacrificed themselves to destroy the hammer. Rather than let the undead despoil the church and the relic, they took the hammer and plunged themselves into the fiery chasm. At that moment, a powerful force of Light washed over the undead legion, striking them down where they stood. Since that time a well-trained Paladin is able to tap the remnants of this released energy, whirling a magical hammer to strike down his adversaries, especially the forces of the walking dead. 
This skill summons a hammer composed of magic power to fly towards the enemy, dealing considerable damage. Demons and undead take 50% extra damage, furthermore, the Undead must save vs. death with a certain penalty or be destroyed. Required Level: 15
  LV15: 6D6 damage, no save penalty; LV20: 6D8 damage, -2 save penalty; LV25: 6D10 damage, -4 save penalty; LV30: 6D12 damage, -6 save penalty.

Conversion
Through force of will and strength of steel, a noble Paladin with this skill is able to blind his enemies with the glory of the Light. After trading blows with the Paladin and facing the fire of righteousness burning in his eyes, an enemy will sometimes be struck with a divine epiphany and momentarily repent his past undertakings. So complete is the transformation, that the converted will turn to slay its former comrades. 
With this skill, a successful attack has a chance to convert the target to fight evil. Convert for 16 Seconds. High-Level skill.
  Before LV25: 30% chance; LV25: 35% chance; LV30: 40% chance; LV35: 45% chance; LV40: 50% chance.

Holy Shield
To a Paladin, the shield is a symbol of his faith. Particularly devout Paladins can channel their faith into their shields, bolstering its defensive value with holy energy. The purer his faith, the greater his defense. 
This skill magically enhances shield to give defense bonuses and block physical attacks as well as spells of offensive damage. A shield must be equipped for activing this skill. High-Level skill.
  Before LV25: +4 bonus to AC, 30% chance to block with a shield, duration 30 seconds; LV25: +5 bonus to AC, 35% chance to block with a shield, duration 60 seconds; LV30: +6 bonus to AC, 40% chance to block with a shield, duration 90 seconds; LV35: +7 bonus to AC, 45% chance to block with a shield, duration 120 seconds; LV40: +8 bonus to AC, 50% chance to block with a shield, duration 150 seconds.

Fist of the Heavens
This spell allows the Paladin to summon the power of holy vengeance. Manifesting as lightning from the heavens, these bolts rain down from the sky, exploding into a thousand shafts of light that radiate outwards to banish the evil from the battlefield. 
This skill calls lightning attack from the sky that releases Holy Bolts (equivalent to Holy Bolts released by a Paladin with a half level of the caster). The victim(s) may make a save vs. death in order to take only half lightning damage. High-Level skill. 
  Before LV25: 8D12 damage; LV25: 10D12 damage; LV30: 12D12 damage; LV35: 14D12 damage; LV40: 16D12 damage.

*Sacrifice, Zeal, Vengeance and Conversion do not take effect at the same time. Each of them will directly replace a pre-casted one.
*After casting of Holy Bolt, Smite and Charge, another skill can be casted immediately.


----------VERSION HISTORY----------

V1.1 Fixed some invalid skills of V1.0.
  Greatly increased all effect ranges of Auras that enhance party members, and made them easy to be triggered in EE games.
  Meditation now gives ability of regeneration as Prayer casted by a Paladin with a half level of the caster.
  Chance of immunity of Concentration increases with character level. 
  Fixed the problem that Thorns does not create animations on allies.
  Fixed transparency of some animations for no EE games.
  Fixed some misplaced descriptions of high-level auras.
  Holy Bolt now damages demons as well as undead.
  Increased chance of blocking of Holy Shield by 5%.
  Increased element resistance of some Auras.
  Simplified the script for Holy Shield.
  Increased effect of Sacrifice.
  Defiance boosts the defense against all 4 types of weapons (Crushing, Missile, Piercing and Slashing) so that AC bonus can continue accumulating when base AC reaches limit of -20.

V1.0 Reconstructed all the aura skills with a new mode, which allows auras to take effect immediately on the Paladin after switching (even in SOLO games), yet require a few seconds to start affecting allies or enemies (similar to original Diablo2). 
   Aura effects no longer pile up when several Paladins start the same aura.
   Many skills now have corresponding sounds and animations, and characters are no longer required to glow as a mark for auras.
  With active Redemption, a rising soul implies successful restoration of health points. Two souls rising at the same time implies successful restoration of skills. 
  Prayer heals with a regenerating process instead of immediately healing. 
  Ajusted skill values of Blessed Hammer, Vigor, Meditation, Concentration and Conviction.
  After casting of Holy Bolt, another skill can be casted immediately.
  AOE skills (e.g. Holy Fire) now ignore the protection of Mirror Image spell (EE only).
  Add skill descriptions from original Diablo2. 

V0.9  Fixed the bug that Holy Shield may not take effect.
   Get aura of Defiance at LV5 and Resist Lightning in LV10.
   Conviction and Salvation becomes High-Level skills.
   Conversion is not necessary when Learning some of the High-Level skills.
   Increased the damage of Vengeance.
   There's no more casting time or casting interval for passive spells which allow the Paladin to enter an offensive mode, e.g. Vengeance and Conversion.

V0.8 Supports EE and original BG2. Unsuperposable Paladin skills in EE is treated as official spells: the later casted spell directly replace the previous one; while in original BG2, a later spell can only be wasted before the expiring of a previous one.
   Rapidly switching between auras of direct attack will no longer deals reduplicative damages.
   Added 10% chance to Conversion.
   Holy Shield no longer presents magic resistance, but generates chance to block physical attacks and spells of offensive damage. Yet the new Holy Shield gives a huge glowing white wiffle ball animation, so a new component for choosing is added to turns off the animation. (This component comes from the Ease of Use Mod Pack, which also turns off the animation for Spell Trap spell and Cloak of Mirroring.)
   Fixed auras' effecting modes to:
   1. Auras of enhancing abilities (Resist Fire, Resist Cold, Resist Lightning, Defiance, Vigor, Salvation, Might, Blessed Aim, Concentration, Fanaticism): Take effect immediately and keep active while any creature is nearby.
   2. Auras of direct attack (Holy Fire, Holy Freeze, Holy Shock, Sanctuary): Immediately attack once when being chosen, then only take effect when enemies are insight.
   3. Auras of regeneration (Meditation, Redemption): After being chosen, only take effect when enemies are insight.
   4. Auras of long term curing (Prayer): Take effect while any creature is nearby.
   5. Auras of curing negative states (Cleansing): The same as 1.
   6. Auras of weakening abilities (Conviction)��The same as 2.
   7. Auras of indirect attack (Thorns)��The same as 3.

V0.7 The problem that some skills disappear with Ctrl+R is fixed.
   Some overpowered skills are weaken.
   Adjusted damage of some skills.
   Five Skill Point can be obtained after 3,000,000 exp from interface of choosing High-Level skills.

V0.6 Auras' swithing no longer takes an extra round.
   Effecting mode of Conviction become the same as auras of regeneration.

V0.5 Sacrifice now increases damage at the cost of 8% health on hit, and no longer kill character on rest.

V0.4 Fixed auras' temporary noneffective to friendly creatures.

V0.3 Improved the effect of Prayer.
   Fixed auras' effecting modes to:
   1. Auras of enhancing abilities (Resist Fire, Resist Cold, Resist Lightning, Defiance, Vigor, Salvation, Might, Blessed Aim, Concentration, Fanaticism): Take effect any time after being chosen.
   2. Auras of regeneration (Prayer, Meditation, Redemption): After being chosen, only take effect when enemies are insight.
   3. Auras of direct attack (Holy Fire, Holy Freeze, Holy Shock, Sanctuary): Immediately attack once when being chosen, then only take effect when enemies are insight.
   4. Auras of curing negative states (Cleansing): The same as 1.
   5. Auras of indirect attack (Thorns)��The same as 2.
   6. Auras of weakening abilities (Conviction)��The same as 2.

V0.2 Fixed the start bonus. Fixed some details in Readme.

V0.1 Finished the Paladin kit.
